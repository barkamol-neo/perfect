export type GameId = 'runner' | 'racer' | 'merge' | 'archer' | 'brain';

export type Language = 'uz' | 'uz_cyr' | 'en' | 'ru';

export interface PlayerProfile {
  name: string;
  avatar: string;
  level: number;
  xp: number;
  coins: number;
  diamonds: number;
  selectedHeroId: string;
  selectedWeaponId: string;
  selectedCarId: string;
  selectedPetId: string | null;
  unlockedHeroIds: string[];
  unlockedWeaponIds: string[];
  unlockedCarIds: string[];
  unlockedPetIds: string[];
  lastDailySpinDate: string | null;
  spinsAvailable: number;
}

export interface GameStats {
  runnerHighScore: number;
  runnerMaxDistance: number;
  runnerBossesDefeated: number;
  racerHighScore: number;
  racerMaxSpeed: number;
  mergeHighScore: number;
  mergeMaxFruitLevel: number;
  archerHighScore: number;
  archerMaxWave: number;
  brainHighScore: number;
  totalCoinsEarned: number;
  totalGamesPlayed: number;
}

export interface HeroItem {
  id: string;
  name: string;
  title: string;
  description: string;
  price: number;
  currency: 'coins' | 'diamonds';
  avatar: string;
  color: string;
  stats: {
    health: number; // base health (e.g. 100-250)
    speed: number;  // speed multiplier
    power: number;  // damage multiplier
    magic: number;  // cooldown reduction
  };
  specialSkill: string;
}

export interface WeaponItem {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: 'coins' | 'diamonds';
  icon: string;
  damage: number;
  element: 'fire' | 'lightning' | 'ice' | 'plasma' | 'gold';
  effectDescription: string;
}

export interface CarItem {
  id: string;
  name: string;
  subtitle: string;
  description: string;
  price: number;
  currency: 'coins' | 'diamonds';
  imageOrEmoji: string;
  color: string;
  stats: {
    topSpeed: number;
    acceleration: number;
    handling: number;
    nitroCapacity: number;
  };
}

export interface PetItem {
  id: string;
  name: string;
  description: string;
  price: number;
  currency: 'coins' | 'diamonds';
  emoji: string;
  perk: string;
  coinMultiplier: number;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  rewardType: 'coins' | 'diamonds';
  rewardAmount: number;
  isUnlocked: boolean;
  progress: number;
  maxProgress: number;
}

export interface DailyQuest {
  id: string;
  title: string;
  description: string;
  targetGame: GameId | 'any';
  rewardType: 'coins' | 'diamonds';
  rewardAmount: number;
  progress: number;
  targetAmount: number;
  isCompleted: boolean;
  isClaimed: boolean;
}

export interface LeaderboardEntry {
  rank: number;
  name: string;
  avatar: string;
  score: number;
  gameId: GameId;
  date: string;
  country?: string;
}

export interface AudioSettings {
  masterVolume: number;
  sfxVolume: number;
  bgmVolume: number;
  sfxMuted: boolean;
  bgmMuted: boolean;
}
