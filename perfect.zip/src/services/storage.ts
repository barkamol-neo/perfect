import {
  PlayerProfile,
  GameStats,
  HeroItem,
  WeaponItem,
  CarItem,
  PetItem,
  Achievement,
  DailyQuest,
  LeaderboardEntry
} from '../types/game';

export const HEROES_CATALOG: HeroItem[] = [
  {
    id: 'temur_warrior',
    name: 'Sohibqiron Temuriy',
    title: 'Qahramon Sarbardor',
    description: 'Qilichbozlik va jasorat timsoli. Barqaror himoya va o\'tkir qilich zarbalari.',
    price: 0,
    currency: 'coins',
    avatar: '🗡️',
    color: 'from-amber-600 to-yellow-500',
    stats: { health: 120, speed: 1.0, power: 1.0, magic: 1.0 },
    specialSkill: 'Qilich bo\'roni (Whirlwind Slash)'
  },
  {
    id: 'cyber_mergan',
    name: 'Kiber Mergan Oybek',
    title: 'Lazer Mergani',
    description: 'Yuqori tezlik va uzoq masofali plazma otish mahorati.',
    price: 800,
    currency: 'coins',
    avatar: '🏹',
    color: 'from-cyan-600 to-blue-500',
    stats: { health: 100, speed: 1.25, power: 1.2, magic: 1.1 },
    specialSkill: 'Tezkor Lazer Otishi (Rapid Laser)'
  },
  {
    id: 'malika_tomiris',
    name: 'Malika Tomiris',
    title: 'Sahro Qirolichasi',
    description: 'Yuksak chidamlilik va qo\'shimcha qalqon qobiliyati.',
    price: 1500,
    currency: 'coins',
    avatar: '👑',
    color: 'from-rose-600 to-pink-500',
    stats: { health: 160, speed: 1.1, power: 1.25, magic: 1.2 },
    specialSkill: 'Sehrli Qalqon (Aegis Shield)'
  },
  {
    id: 'jaloliddin',
    name: 'Jaloliddin Manguberdi',
    title: 'Yengilmas Bahodir',
    description: 'Olovli g\'azab bilan jang qiluvchi jasur sarkarda.',
    price: 2800,
    currency: 'coins',
    avatar: '🔥',
    color: 'from-red-600 to-orange-500',
    stats: { health: 150, speed: 1.15, power: 1.45, magic: 1.15 },
    specialSkill: 'Olovli G\'azab (Flame Rage)'
  },
  {
    id: 'kiber_navoiy',
    name: 'Donishmand Navoiy',
    title: 'Kiber Sehrgar',
    description: 'Chaqmoq va sirli yozuvlar sehri orqali dushmanlarni yo\'q qiladi.',
    price: 4500,
    currency: 'coins',
    avatar: '⚡',
    color: 'from-purple-600 to-indigo-500',
    stats: { health: 130, speed: 1.1, power: 1.5, magic: 1.5 },
    specialSkill: 'Chaqmoq Bo\'roni (Lightning Storm)'
  },
  {
    id: 'al_xorazmiy',
    name: 'Kvant Al-Xorazmiy',
    title: 'Vaqt Boshqaruvchisi',
    description: 'Algoritmik vaqtni sekinlashtirish va fazoviy sakrash egasi.',
    price: 35,
    currency: 'diamonds',
    avatar: '⏳',
    color: 'from-teal-600 to-emerald-500',
    stats: { health: 140, speed: 1.3, power: 1.6, magic: 1.6 },
    specialSkill: 'Vaqtni To\'xtatish (Time Dilation)'
  },
  {
    id: 'samarqand_shohi',
    name: 'Oltin Humo Shahzodasi',
    title: 'Afsonaviy Shoh',
    description: 'Barcha tanga va olmoslarni 2 barobar ko\'paytiruvchi magnit.',
    price: 75,
    currency: 'diamonds',
    avatar: '🦅',
    color: 'from-yellow-500 to-amber-400',
    stats: { health: 180, speed: 1.25, power: 1.7, magic: 1.4 },
    specialSkill: '2x Oltin Yomg\'iri (Gold Rain)'
  },
  {
    id: 'robo_alpombish',
    name: 'Cyber Alpombish MK-3',
    title: 'Titan Dev',
    description: 'O\'ta yuqori himoya va yerni larzaga soluvchi seysmik zarba.',
    price: 120,
    currency: 'diamonds',
    avatar: '🦾',
    color: 'from-slate-700 to-zinc-900',
    stats: { health: 240, speed: 1.0, power: 2.0, magic: 1.0 },
    specialSkill: 'Zilzila Zarbasi (Seismic Shockwave)'
  }
];

export const WEAPONS_CATALOG: WeaponItem[] = [
  {
    id: 'damashq_qilich',
    name: 'Damashq Po\'lat Qilichi',
    description: 'Qadimiy temirchilar tomonidan zarb qilingan o\'tkir qilich.',
    price: 0,
    currency: 'coins',
    icon: '⚔️',
    damage: 25,
    element: 'steel' as any,
    effectDescription: 'Klassik o\'tkir zarba'
  },
  {
    id: 'olovli_shamshir',
    name: 'Olovli Shamshir',
    description: 'Dushmanlarni kuydiruvchi yonar tig\'.',
    price: 600,
    currency: 'coins',
    icon: '🗡️🔥',
    damage: 40,
    element: 'fire',
    effectDescription: 'Dushmanlarni 3 soniya yondiradi'
  },
  {
    id: 'chaqmoq_nayza',
    name: 'Chaqmoq Nayzasi',
    description: 'Zarba tekkanida atrofga chaqmoq zanjirini sochadi.',
    price: 1200,
    currency: 'coins',
    icon: '🔱⚡',
    damage: 55,
    element: 'lightning',
    effectDescription: 'Atrofdagi 3 dushmanga zanjirli chaqmoq'
  },
  {
    id: 'muz_pichoq',
    name: 'Muzli Qilich',
    description: 'Dushmanlarni muzlatadi va harakatini 50% sekinlashtiradi.',
    price: 2000,
    currency: 'coins',
    icon: '❄️🗡️',
    damage: 50,
    element: 'ice',
    effectDescription: 'Sekinlashtirish va muzlatish'
  },
  {
    id: 'kiber_laser',
    name: 'Plazma Laser Qilich',
    description: 'Barcha to\'siq va dushmanlarni teshib o\'tuvchi kiber nur.',
    price: 3500,
    currency: 'coins',
    icon: '🌌🗡️',
    damage: 75,
    element: 'plasma',
    effectDescription: 'Bir zarbada qatordagi barcha dushmanlarni teshib o\'tish'
  },
  {
    id: 'humo_xanjari',
    name: 'Oltin Humo Xanjari',
    description: 'O\'ldirilgan dushmandan 2x tanga va kritik zarbalar.',
    price: 50,
    currency: 'diamonds',
    icon: '👑🗡️',
    damage: 95,
    element: 'gold',
    effectDescription: '2x Tangalar va +50% Kritik Zarb'
  }
];

export const CARS_CATALOG: CarItem[] = [
  {
    id: 'damas_turbo',
    name: 'Damas Turbo Express',
    subtitle: 'Shaharlararo Raketa',
    description: 'Ajoyib burilishlar, tezkor manyovr va ixcham o\'lcham.',
    price: 0,
    currency: 'coins',
    imageOrEmoji: '🚐',
    color: 'from-amber-500 to-yellow-400',
    stats: { topSpeed: 180, acceleration: 70, handling: 90, nitroCapacity: 80 }
  },
  {
    id: 'nexia_sport',
    name: 'Nexia 3 GT Sport',
    subtitle: 'Klassik Poygachi',
    description: 'Barqaror tezlik va qulay rul boshqaruvi.',
    price: 800,
    currency: 'coins',
    imageOrEmoji: '🚗',
    color: 'from-blue-600 to-cyan-500',
    stats: { topSpeed: 210, acceleration: 80, handling: 85, nitroCapacity: 90 }
  },
  {
    id: 'cobalt_drift',
    name: 'Cobalt Street Drift',
    subtitle: 'Tungi Ko\'chalar Qiroli',
    description: 'Aylanma burilishlarda yuqori drift va tezlanish.',
    price: 1800,
    currency: 'coins',
    imageOrEmoji: '🚙',
    color: 'from-purple-600 to-indigo-500',
    stats: { topSpeed: 235, acceleration: 88, handling: 92, nitroCapacity: 95 }
  },
  {
    id: 'gentra_mafia',
    name: 'Gentra Black Edition',
    subtitle: 'Qora Bumerang',
    description: 'Kuchli zirh, raqiblarni surib tashlash va uzoq nitro.',
    price: 3200,
    currency: 'coins',
    imageOrEmoji: '🚘',
    color: 'from-slate-800 to-black',
    stats: { topSpeed: 260, acceleration: 92, handling: 86, nitroCapacity: 110 }
  },
  {
    id: 'malibu_v6',
    name: 'Malibu Cyber Turbo V6',
    subtitle: 'Premium Giperkar',
    description: 'O\'ta yuqori maksimal tezlik va qulaylik.',
    price: 5000,
    currency: 'coins',
    imageOrEmoji: '🏎️',
    color: 'from-red-600 to-rose-500',
    stats: { topSpeed: 295, acceleration: 96, handling: 94, nitroCapacity: 120 }
  },
  {
    id: 'bolid_x1',
    name: 'Cyber Bolid Formula X-1',
    subtitle: 'Tovushdan Tez Kosmik Mashina',
    description: 'Antigravitatsiya, cheksiz drift va yorug\'lik tezligi.',
    price: 60,
    currency: 'diamonds',
    imageOrEmoji: '🛸',
    color: 'from-cyan-400 to-emerald-400',
    stats: { topSpeed: 360, acceleration: 100, handling: 98, nitroCapacity: 150 }
  }
];

export const PETS_CATALOG: PetItem[] = [
  {
    id: 'humo_burgut',
    name: 'Humo Burguti',
    description: 'Tepadan uchib barcha tangalarni sizga olib keladi.',
    price: 1000,
    currency: 'coins',
    emoji: '🦅',
    perk: 'Tangalarni avto-tortish & +20% ball',
    coinMultiplier: 1.2
  },
  {
    id: 'qor_qoplon',
    name: 'Chortoq Qor Qoploni',
    description: 'Yoningizda yugurib dushmanlarga zarba beradi.',
    price: 2500,
    currency: 'coins',
    emoji: '🐆',
    perk: '+35% Tangalar & Qo\'shimcha zarba',
    coinMultiplier: 1.35
  },
  {
    id: 'kiber_dron',
    name: 'Kiber Dron Bot-01',
    description: 'Sizni lazer bilan himoya qiladi va qalqon beradi.',
    price: 40,
    currency: 'diamonds',
    emoji: '🤖',
    perk: 'Qalqonni har 20s tiklash & +50% tanga',
    coinMultiplier: 1.5
  }
];

export const DEFAULT_ACHIEVEMENTS: Achievement[] = [
  {
    id: 'first_run',
    title: 'Birinchi Qadam',
    description: 'Registon Runner o\'yinida 500 metr masofani bosib o\'ting',
    icon: '🏃',
    rewardType: 'coins',
    rewardAmount: 200,
    isUnlocked: false,
    progress: 0,
    maxProgress: 500
  },
  {
    id: 'boss_slayer_1',
    title: 'Devlarni Yenguvchi',
    description: 'Kamida 1 ta Dev Bossini mag\'lub qiling',
    icon: '👹',
    rewardType: 'diamonds',
    rewardAmount: 5,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'coin_collector_1000',
    title: 'Xazina Izlovchi',
    description: 'Jami 1,000 dona oltin tanga yig\'ing',
    icon: '💰',
    rewardType: 'coins',
    rewardAmount: 500,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1000
  },
  {
    id: 'speed_demon_250',
    title: 'Tezlik Qiroli',
    description: 'Poygada 250 km/soat tezlikka erishing',
    icon: '🏎️',
    rewardType: 'coins',
    rewardAmount: 400,
    isUnlocked: false,
    progress: 0,
    maxProgress: 250
  },
  {
    id: 'merge_watermelon',
    title: 'Meva Ustasi',
    description: 'Suika o\'yinida Qandak Tarvuz yoki Somsa hosil qiling',
    icon: '🍉',
    rewardType: 'diamonds',
    rewardAmount: 8,
    isUnlocked: false,
    progress: 0,
    maxProgress: 1
  },
  {
    id: 'archer_wave_5',
    title: 'Qal\'a Qo\'riqchisi',
    description: 'Kiber Mergan o\'yinida 5-to\'lqinni muvaffaqiyatli yakunlang',
    icon: '🏰',
    rewardType: 'coins',
    rewardAmount: 600,
    isUnlocked: false,
    progress: 0,
    maxProgress: 5
  },
  {
    id: 'brain_score_100',
    title: 'Chaqmoq Aql',
    description: 'Zehn va Reaksiya o\'yinida 100 balldan oshiring',
    icon: '🧠',
    rewardType: 'diamonds',
    rewardAmount: 10,
    isUnlocked: false,
    progress: 0,
    maxProgress: 100
  },
  {
    id: 'rich_hero',
    title: 'Boy Qahramon',
    description: 'Jami 5,000 tanga to\'plang',
    icon: '👑',
    rewardType: 'diamonds',
    rewardAmount: 15,
    isUnlocked: false,
    progress: 0,
    maxProgress: 5000
  }
];

export const DEFAULT_DAILY_QUESTS: DailyQuest[] = [
  {
    id: 'quest_run_1000',
    title: 'Samarqand Bo\'ylab Chopish',
    description: 'Registon Runnerda 1,000 metr masofani bosib o\'ting',
    targetGame: 'runner',
    rewardType: 'coins',
    rewardAmount: 350,
    progress: 0,
    targetAmount: 1000,
    isCompleted: false,
    isClaimed: false
  },
  {
    id: 'quest_racer_nitro',
    title: 'Nitro Chaqnash',
    description: 'Poygada 5 marta Nitro bosishni amalga oshiring',
    targetGame: 'racer',
    rewardType: 'coins',
    rewardAmount: 300,
    progress: 0,
    targetAmount: 5,
    isCompleted: false,
    isClaimed: false
  },
  {
    id: 'quest_merge_500',
    title: 'Shirin Birlashuv',
    description: 'Meva o\'yinida 500 ball to\'plang',
    targetGame: 'merge',
    rewardType: 'coins',
    rewardAmount: 250,
    progress: 0,
    targetAmount: 500,
    isCompleted: false,
    isClaimed: false
  },
  {
    id: 'quest_archer_kills',
    title: 'Dronlarni Yo\'q Qilish',
    description: 'Kiber Merganda 15 ta dushman dronini urib tushiring',
    targetGame: 'archer',
    rewardType: 'diamonds',
    rewardAmount: 3,
    progress: 0,
    targetAmount: 15,
    isCompleted: false,
    isClaimed: false
  },
  {
    id: 'quest_play_games',
    title: 'Faol O\'yinchi',
    description: 'Ixtiyoriy 3 ta o\'yin o\'ynang',
    targetGame: 'any',
    rewardType: 'diamonds',
    rewardAmount: 5,
    progress: 0,
    targetAmount: 3,
    isCompleted: false,
    isClaimed: false
  }
];

export const MOCK_LEADERBOARDS: LeaderboardEntry[] = [
  { rank: 1, name: 'Sardor_Pro', avatar: '👑', score: 14820, gameId: 'runner', date: 'Bugun', country: 'UZ' },
  { rank: 2, name: 'Temur_Gamer', avatar: '⚔️', score: 12450, gameId: 'runner', date: 'Bugun', country: 'UZ' },
  { rank: 3, name: 'Madina_Cyber', avatar: '🚀', score: 11100, gameId: 'runner', date: 'Kecha', country: 'UZ' },
  { rank: 4, name: 'Bekzod_Speed', avatar: '🏎️', score: 9800, gameId: 'runner', date: '2 kun oldin', country: 'UZ' },
  { rank: 5, name: 'Azizbek_Sam', avatar: '🦅', score: 8750, gameId: 'runner', date: '3 kun oldin', country: 'UZ' },
];

const STORAGE_KEYS = {
  PROFILE: 'qahramon_player_profile_v1',
  STATS: 'qahramon_game_stats_v1',
  ACHIEVEMENTS: 'qahramon_achievements_v1',
  QUESTS: 'qahramon_daily_quests_v1',
  QUESTS_DATE: 'qahramon_quests_date_v1',
  LEADERBOARD: 'qahramon_leaderboard_v1',
};

class StorageService {
  public getProfile(): PlayerProfile {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.PROFILE);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error(e);
    }
    const defaultProfile: PlayerProfile = {
      name: 'Qahramon_' + Math.floor(1000 + Math.random() * 9000),
      avatar: '🗡️',
      level: 1,
      xp: 0,
      coins: 300, // Starter bonus!
      diamonds: 5, // Starter diamonds!
      selectedHeroId: 'temur_warrior',
      selectedWeaponId: 'damashq_qilich',
      selectedCarId: 'damas_turbo',
      selectedPetId: null,
      unlockedHeroIds: ['temur_warrior'],
      unlockedWeaponIds: ['damashq_qilich'],
      unlockedCarIds: ['damas_turbo'],
      unlockedPetIds: [],
      lastDailySpinDate: null,
      spinsAvailable: 1
    };
    this.saveProfile(defaultProfile);
    return defaultProfile;
  }

  public saveProfile(profile: PlayerProfile) {
    try {
      localStorage.setItem(STORAGE_KEYS.PROFILE, JSON.stringify(profile));
    } catch (e) {
      console.error(e);
    }
  }

  public getStats(): GameStats {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.STATS);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error(e);
    }
    const defaultStats: GameStats = {
      runnerHighScore: 0,
      runnerMaxDistance: 0,
      runnerBossesDefeated: 0,
      racerHighScore: 0,
      racerMaxSpeed: 0,
      mergeHighScore: 0,
      mergeMaxFruitLevel: 0,
      archerHighScore: 0,
      archerMaxWave: 0,
      brainHighScore: 0,
      totalCoinsEarned: 0,
      totalGamesPlayed: 0
    };
    this.saveStats(defaultStats);
    return defaultStats;
  }

  public saveStats(stats: GameStats) {
    try {
      localStorage.setItem(STORAGE_KEYS.STATS, JSON.stringify(stats));
    } catch (e) {
      console.error(e);
    }
  }

  public getAchievements(): Achievement[] {
    try {
      const data = localStorage.getItem(STORAGE_KEYS.ACHIEVEMENTS);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error(e);
    }
    this.saveAchievements(DEFAULT_ACHIEVEMENTS);
    return DEFAULT_ACHIEVEMENTS;
  }

  public saveAchievements(achievements: Achievement[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.ACHIEVEMENTS, JSON.stringify(achievements));
    } catch (e) {
      console.error(e);
    }
  }

  public getDailyQuests(): DailyQuest[] {
    const today = new Date().toISOString().split('T')[0];
    const savedDate = localStorage.getItem(STORAGE_KEYS.QUESTS_DATE);
    if (savedDate !== today) {
      // Reset daily quests for new day
      localStorage.setItem(STORAGE_KEYS.QUESTS_DATE, today);
      this.saveDailyQuests(DEFAULT_DAILY_QUESTS);
      return DEFAULT_DAILY_QUESTS;
    }
    try {
      const data = localStorage.getItem(STORAGE_KEYS.QUESTS);
      if (data) return JSON.parse(data);
    } catch (e) {
      console.error(e);
    }
    return DEFAULT_DAILY_QUESTS;
  }

  public saveDailyQuests(quests: DailyQuest[]) {
    try {
      localStorage.setItem(STORAGE_KEYS.QUESTS, JSON.stringify(quests));
    } catch (e) {
      console.error(e);
    }
  }

  public addCoinsAndDiamonds(coins: number, diamonds: number = 0) {
    const profile = this.getProfile();
    profile.coins += Math.max(0, coins);
    profile.diamonds += Math.max(0, diamonds);

    // XP calculation: 1 coin = 1 XP
    profile.xp += coins;
    const nextLevelXp = profile.level * 500;
    if (profile.xp >= nextLevelXp) {
      profile.level += 1;
      profile.diamonds += 2; // Level up reward!
    }

    this.saveProfile(profile);

    const stats = this.getStats();
    stats.totalCoinsEarned += coins;
    this.saveStats(stats);

    return profile;
  }

  public resetAll() {
    localStorage.clear();
  }
}

export const storage = new StorageService();
