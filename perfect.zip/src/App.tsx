import { useState, useEffect } from 'react';
import { PlayerProfile, GameId, Language } from './types/game';
import { storage } from './services/storage';
import { getTranslation } from './services/localization';
import { sound } from './services/sound';

// Components
import { Header } from './components/Header';
import { RunnerGame } from './components/games/RunnerGame';
import { RacerGame } from './components/games/RacerGame';
import { MergeGame } from './components/games/MergeGame';
import { ArcherGame } from './components/games/ArcherGame';
import { BrainGame } from './components/games/BrainGame';

// Modals
import { ShopModal } from './components/modals/ShopModal';
import { LuckyWheelModal } from './components/modals/LuckyWheelModal';
import { AchievementsModal } from './components/modals/AchievementsModal';
import { QuestsModal } from './components/modals/QuestsModal';
import { LeaderboardModal } from './components/modals/LeaderboardModal';
import { ProfileModal } from './components/modals/ProfileModal';
import { SettingsModal } from './components/modals/SettingsModal';

import { 
  Play, Sparkles, Trophy, ShoppingBag, Target, Award,
  Gamepad2
} from 'lucide-react';

export function App() {
  const [profile, setProfile] = useState<PlayerProfile>(() => storage.getProfile());
  const [language, setLanguage] = useState<Language>('uz');
  const [activeGame, setActiveGame] = useState<GameId | null>(null);

  // Modals state
  const [isShopOpen, setIsShopOpen] = useState(false);
  const [isWheelOpen, setIsWheelOpen] = useState(false);
  const [isQuestsOpen, setIsQuestsOpen] = useState(false);
  const [isAchievementsOpen, setIsAchievementsOpen] = useState(false);
  const [isLeaderboardOpen, setIsLeaderboardOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  const t = getTranslation(language);

  // Sync profile on mount
  useEffect(() => {
    setProfile(storage.getProfile());
  }, []);

  const handleUpdateProfile = (updated: PlayerProfile) => {
    setProfile({ ...updated });
  };

  const handleLaunchGame = (gameId: GameId) => {
    sound.playClick();
    setActiveGame(gameId);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleBackToHub = () => {
    sound.playClick();
    setActiveGame(null);
    sound.stopBgm();
  };

  const gamesCatalog = [
    {
      id: 'runner' as GameId,
      title: t.game1Title,
      desc: t.game1Desc,
      tag: t.game1Tag,
      icon: '🗡️',
      badgeColor: 'from-amber-500 to-yellow-500',
      gradient: 'from-amber-950/80 via-slate-900 to-slate-950 border-amber-500/40 hover:border-amber-400',
      glow: 'glow-gold',
      btnText: t.playNow,
      players: '12.4k o\'yinchi'
    },
    {
      id: 'racer' as GameId,
      title: t.game2Title,
      desc: t.game2Desc,
      tag: t.game2Tag,
      icon: '🏎️',
      badgeColor: 'from-cyan-500 to-blue-500',
      gradient: 'from-cyan-950/80 via-slate-900 to-slate-950 border-cyan-500/40 hover:border-cyan-400',
      glow: 'glow-cyan',
      btnText: t.playNow,
      players: '9.8k o\'yinchi'
    },
    {
      id: 'merge' as GameId,
      title: t.game3Title,
      desc: t.game3Desc,
      tag: t.game3Tag,
      icon: '🍉',
      badgeColor: 'from-emerald-500 to-green-500',
      gradient: 'from-emerald-950/80 via-slate-900 to-slate-950 border-emerald-500/40 hover:border-emerald-400',
      glow: 'glow-green',
      btnText: t.playNow,
      players: '15.1k o\'yinchi'
    },
    {
      id: 'archer' as GameId,
      title: t.game4Title,
      desc: t.game4Desc,
      tag: t.game4Tag,
      icon: '🏹',
      badgeColor: 'from-purple-500 to-indigo-500',
      gradient: 'from-purple-950/80 via-slate-900 to-slate-950 border-purple-500/40 hover:border-purple-400',
      glow: 'glow-pink',
      btnText: t.playNow,
      players: '8.3k o\'yinchi'
    },
    {
      id: 'brain' as GameId,
      title: t.game5Title,
      desc: t.game5Desc,
      tag: t.game5Tag,
      icon: '🧠',
      badgeColor: 'from-rose-500 to-pink-500',
      gradient: 'from-rose-950/80 via-slate-900 to-slate-950 border-rose-500/40 hover:border-rose-400',
      glow: 'glow-pink',
      btnText: t.playNow,
      players: '11.0k o\'yinchi'
    }
  ];

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 flex flex-col selection:bg-amber-500 selection:text-slate-950 relative overflow-x-hidden">
      {/* Background Neon Grid Ambience */}
      <div className="fixed inset-0 pointer-events-none opacity-20 z-0">
        <div className="absolute top-0 left-1/4 w-96 h-96 bg-amber-500/20 rounded-full blur-[120px]" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-[120px]" />
      </div>

      {/* Top Header */}
      <Header
        profile={profile}
        language={language}
        onOpenShop={() => setIsShopOpen(true)}
        onOpenWheel={() => setIsWheelOpen(true)}
        onOpenQuests={() => setIsQuestsOpen(true)}
        onOpenAchievements={() => setIsAchievementsOpen(true)}
        onOpenLeaderboard={() => setIsLeaderboardOpen(true)}
        onOpenProfile={() => setIsProfileOpen(true)}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />

      {/* Main Container */}
      <main className="flex-1 w-full max-w-7xl mx-auto px-3 sm:px-6 py-4 sm:py-6 relative z-10 flex flex-col">
        {/* If Active Game is playing */}
        {activeGame === 'runner' && (
          <RunnerGame
            profile={profile}
            language={language}
            onUpdateProfile={handleUpdateProfile}
            onBackToHub={handleBackToHub}
          />
        )}

        {activeGame === 'racer' && (
          <RacerGame
            profile={profile}
            language={language}
            onUpdateProfile={handleUpdateProfile}
            onBackToHub={handleBackToHub}
          />
        )}

        {activeGame === 'merge' && (
          <MergeGame
            profile={profile}
            language={language}
            onUpdateProfile={handleUpdateProfile}
            onBackToHub={handleBackToHub}
          />
        )}

        {activeGame === 'archer' && (
          <ArcherGame
            profile={profile}
            language={language}
            onUpdateProfile={handleUpdateProfile}
            onBackToHub={handleBackToHub}
          />
        )}

        {activeGame === 'brain' && (
          <BrainGame
            profile={profile}
            language={language}
            onUpdateProfile={handleUpdateProfile}
            onBackToHub={handleBackToHub}
          />
        )}

        {/* If on Games Portal Hub */}
        {!activeGame && (
          <div className="flex flex-col gap-6 sm:gap-8">
            {/* Hero Featured Showcase Banner */}
            <div className="relative w-full rounded-3xl overflow-hidden bg-gradient-to-r from-amber-950 via-slate-900 to-indigo-950 border-2 border-amber-500/40 p-6 sm:p-10 shadow-2xl flex flex-col md:flex-row items-center justify-between gap-6">
              <div className="flex-1 text-center md:text-left">
                <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/30 text-amber-400 rounded-full text-xs font-bold mb-3">
                  <Sparkles className="w-3.5 h-3.5" />
                  <span>KIBER SAMARQAND SARGUZASHTI</span>
                </div>

                <h2 className="text-2xl sm:text-4xl lg:text-5xl font-black text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-200 to-yellow-500 font-russo tracking-wide mb-3 leading-tight">
                  Registon Qahramoni: Cyber Runner
                </h2>

                <p className="text-slate-300 text-xs sm:text-sm max-w-xl mb-6 leading-relaxed">
                  Tungi Samarqand bo'ylab yuguring, kiber dushmanlarni sehr va qilich bilan mag'lub qiling, tangalarni to'plang va har 1000 metrda Dev bosslari bilan jang qiling!
                </p>

                <div className="flex flex-wrap items-center justify-center md:justify-start gap-3">
                  <button
                    onClick={() => handleLaunchGame('runner')}
                    className="px-7 py-3.5 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-sm sm:text-base rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition flex items-center gap-2.5 glow-gold"
                  >
                    <Play className="w-5 h-5 fill-slate-950" />
                    <span>Hozir O'ynash</span>
                  </button>

                  <button
                    onClick={() => setIsShopOpen(true)}
                    className="px-5 py-3.5 bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-xs sm:text-sm rounded-2xl transition flex items-center gap-2"
                  >
                    <ShoppingBag className="w-4 h-4 text-amber-400" />
                    <span>Arsenal & Qahramonlar</span>
                  </button>

                  <button
                    onClick={() => setIsWheelOpen(true)}
                    className="px-5 py-3.5 bg-slate-900/80 hover:bg-slate-800 text-slate-200 border border-slate-700 font-bold text-xs sm:text-sm rounded-2xl transition flex items-center gap-2"
                  >
                    <Sparkles className="w-4 h-4 text-yellow-400" />
                    <span>Omad G'ildiragi</span>
                  </button>
                </div>
              </div>

              {/* Banner Visual Icon & Float */}
              <div className="relative flex items-center justify-center p-6 shrink-0">
                <div className="w-36 h-36 sm:w-48 sm:h-48 rounded-full bg-amber-500/10 border-2 border-amber-500/30 flex items-center justify-center text-7xl sm:text-8xl shadow-2xl animate-float">
                  🗡️
                </div>
              </div>
            </div>

            {/* Quick Stat & Reward Bar */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div
                onClick={() => setIsWheelOpen(true)}
                className="p-3.5 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 rounded-2xl cursor-pointer transition flex items-center gap-3 shadow-md"
              >
                <div className="p-2.5 bg-yellow-500/10 text-yellow-400 rounded-xl text-xl">
                  🎁
                </div>
                <div>
                  <div className="text-xs text-slate-400">Omad G'ildiragi</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-100">
                    {profile.spinsAvailable > 0 ? 'Bepul Spin bor!' : 'Har kuni sovg\'a'}
                  </div>
                </div>
              </div>

              <div
                onClick={() => setIsQuestsOpen(true)}
                className="p-3.5 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 rounded-2xl cursor-pointer transition flex items-center gap-3 shadow-md"
              >
                <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-xl">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Kunlik Vazifalar</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-100">5 ta vazifa</div>
                </div>
              </div>

              <div
                onClick={() => setIsAchievementsOpen(true)}
                className="p-3.5 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 rounded-2xl cursor-pointer transition flex items-center gap-3 shadow-md"
              >
                <div className="p-2.5 bg-yellow-500/10 text-yellow-400 rounded-xl">
                  <Award className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Yutuqlar</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-100">Medallar & Mukofot</div>
                </div>
              </div>

              <div
                onClick={() => setIsLeaderboardOpen(true)}
                className="p-3.5 bg-slate-900/90 hover:bg-slate-800/90 border border-slate-800 rounded-2xl cursor-pointer transition flex items-center gap-3 shadow-md"
              >
                <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-xl">
                  <Trophy className="w-5 h-5" />
                </div>
                <div>
                  <div className="text-xs text-slate-400">Liderlar</div>
                  <div className="text-xs sm:text-sm font-bold text-slate-100">Reytingda 1-o'rin</div>
                </div>
              </div>
            </div>

            {/* Games Catalog Section */}
            <div>
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Gamepad2 className="w-6 h-6 text-amber-400" />
                  <h3 className="text-lg sm:text-2xl font-black text-slate-100 font-russo">
                    Barcha O'yinlar Katalogi
                  </h3>
                </div>
                <span className="text-xs text-slate-400">5 ta to'liq o'yin</span>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6">
                {gamesCatalog.map((game) => (
                  <div
                    key={game.id}
                    className={`relative rounded-3xl border-2 p-5 sm:p-6 bg-gradient-to-br ${game.gradient} flex flex-col justify-between transition-all duration-300 hover:scale-[1.02] shadow-xl group`}
                  >
                    <div>
                      {/* Top Tag & Players */}
                      <div className="flex items-center justify-between mb-4">
                        <span className={`px-3 py-1 rounded-xl text-[10px] font-black uppercase tracking-wider bg-gradient-to-r ${game.badgeColor} text-slate-950 font-mono`}>
                          {game.tag}
                        </span>
                        <span className="text-xs text-slate-400 font-medium">{game.players}</span>
                      </div>

                      {/* Icon & Title */}
                      <div className="flex items-start gap-3.5 mb-3">
                        <span className="text-4xl p-2.5 bg-slate-950/80 rounded-2xl border border-slate-800 shadow-md group-hover:scale-110 transition">
                          {game.icon}
                        </span>
                        <div>
                          <h4 className="font-extrabold text-lg sm:text-xl text-slate-100 font-russo leading-snug">
                            {game.title}
                          </h4>
                        </div>
                      </div>

                      <p className="text-xs sm:text-sm text-slate-300 mb-6 leading-relaxed">
                        {game.desc}
                      </p>
                    </div>

                    <button
                      onClick={() => handleLaunchGame(game.id)}
                      className="w-full py-3 bg-gradient-to-r from-slate-100 to-slate-200 hover:from-white hover:to-slate-100 text-slate-950 font-black text-sm rounded-xl shadow-lg transition flex items-center justify-center gap-2 group-hover:shadow-2xl active:scale-95"
                    >
                      <Play className="w-4 h-4 fill-slate-950" />
                      <span>{t.playNow}</span>
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="w-full border-t border-slate-800 bg-slate-950/90 py-6 px-4 text-center text-xs text-slate-500 relative z-10 mt-12">
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-lg">👑</span>
            <span className="font-bold text-slate-300">Qahramonlar Makoni</span>
            <span>• Cyber Samarqand & Retro O'yinlar</span>
          </div>
          <div>
            Web Audio API Synth • 60 FPS Canvas Physics • O'zbekcha / English / Русский
          </div>
        </div>
      </footer>

      {/* Modals */}
      <ShopModal
        profile={profile}
        language={language}
        isOpen={isShopOpen}
        onClose={() => setIsShopOpen(false)}
        onUpdateProfile={handleUpdateProfile}
      />

      <LuckyWheelModal
        profile={profile}
        language={language}
        isOpen={isWheelOpen}
        onClose={() => setIsWheelOpen(false)}
        onUpdateProfile={handleUpdateProfile}
      />

      <AchievementsModal
        profile={profile}
        language={language}
        isOpen={isAchievementsOpen}
        onClose={() => setIsAchievementsOpen(false)}
        onUpdateProfile={handleUpdateProfile}
      />

      <QuestsModal
        profile={profile}
        language={language}
        isOpen={isQuestsOpen}
        onClose={() => setIsQuestsOpen(false)}
        onUpdateProfile={handleUpdateProfile}
      />

      <LeaderboardModal
        profile={profile}
        language={language}
        isOpen={isLeaderboardOpen}
        onClose={() => setIsLeaderboardOpen(false)}
      />

      <ProfileModal
        profile={profile}
        language={language}
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        onUpdateProfile={handleUpdateProfile}
      />

      <SettingsModal
        language={language}
        isOpen={isSettingsOpen}
        onClose={() => setIsSettingsOpen(false)}
        onLanguageChange={(lang) => setLanguage(lang)}
        onResetAllData={() => setProfile(storage.getProfile())}
      />
    </div>
  );
}
export default App;
