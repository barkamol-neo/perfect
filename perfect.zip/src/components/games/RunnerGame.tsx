import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage, HEROES_CATALOG, WEAPONS_CATALOG, PETS_CATALOG } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { 
  Play, RotateCcw, Volume2, VolumeX, Zap, Sparkles, 
  Flame, Heart, Trophy, ArrowLeft
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface RunnerGameProps {
  profile: PlayerProfile;
  language: Language;
  onUpdateProfile: (profile: PlayerProfile) => void;
  onBackToHub: () => void;
}

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
  maxLife: number;
}

interface FloatingText {
  id: number;
  text: string;
  x: number;
  y: number;
  color: string;
  size: number;
  life: number;
}

interface Projectile {
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  color: string;
  damage: number;
  isPlayer: boolean;
  type: 'slash' | 'fire' | 'lightning' | 'laser';
}

interface Enemy {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  type: 'ground_crawler' | 'flying_drone' | 'spear_bot' | 'boss';
  hp: number;
  maxHp: number;
  speed: number;
  attackCooldown: number;
  color: string;
  isBoss?: boolean;
  bossPhase?: number;
}

interface Collectible {
  id: number;
  x: number;
  y: number;
  type: 'coin' | 'diamond' | 'heart' | 'shield' | 'magnet' | 'star';
  radius: number;
  collected?: boolean;
}

export const RunnerGame: React.FC<RunnerGameProps> = ({
  profile,
  language,
  onUpdateProfile,
  onBackToHub
}) => {
  const t = getTranslation(language);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Equipped stats
  const hero = HEROES_CATALOG.find(h => h.id === profile.selectedHeroId) || HEROES_CATALOG[0];
  const weapon = WEAPONS_CATALOG.find(w => w.id === profile.selectedWeaponId) || WEAPONS_CATALOG[0];
  const pet = PETS_CATALOG.find(p => p.id === profile.selectedPetId);

  // React states
  const [gameState, setGameState] = useState<'menu' | 'playing' | 'paused' | 'gameover'>('menu');
  const [score, setScore] = useState(0);
  const [coinsCollected, setCoinsCollected] = useState(0);
  const [diamondsCollected, setDiamondsCollected] = useState(0);
  const [distance, setDistance] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [bossActive, setBossActive] = useState(false);
  const [bossHp, setBossHp] = useState({ current: 100, max: 100 });
  const [combo, setCombo] = useState(1);
  const [hp, setHp] = useState(hero.stats.health);
  const [mana, setMana] = useState(100);
  const [, setIsShielded] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Engine refs to avoid stale closures in requestAnimationFrame
  const engineRef = useRef({
    distance: 0,
    speed: 6.5,
    heroX: 140,
    heroY: 340,
    heroVy: 0,
    isGrounded: true,
    jumpCount: 0,
    dashTimer: 0,
    dashCooldown: 0,
    slashTimer: 0,
    spellCooldown: 0,
    hp: hero.stats.health,
    maxHp: hero.stats.health,
    mana: 100,
    isShielded: false,
    magnetTimer: 0,
    score: 0,
    coins: 0,
    diamonds: 0,
    combo: 1,
    comboTimer: 0,
    enemies: [] as Enemy[],
    projectiles: [] as Projectile[],
    collectibles: [] as Collectible[],
    particles: [] as Particle[],
    floatingTexts: [] as FloatingText[],
    shake: 0,
    nextEnemyDist: 400,
    nextCoinDist: 200,
    nextBossDist: 1000,
    bossDefeatedCount: 0,
    stars: [] as { x: number; y: number; s: number; alpha: number }[],
    groundOffset: 0,
    keys: {
      left: false,
      right: false,
      jump: false,
      attack: false,
      magic: false,
      dash: false
    }
  });

  // Load highscore
  useEffect(() => {
    const stats = storage.getStats();
    setHighScore(stats.runnerHighScore);
    sound.startBgm('cyber_silkroad');

    return () => {
      sound.stopBgm();
    };
  }, []);

  // Init stars for parallax
  useEffect(() => {
    const stars = [];
    for (let i = 0; i < 70; i++) {
      stars.push({
        x: Math.random() * 1200,
        y: Math.random() * 400,
        s: Math.random() * 2 + 1,
        alpha: Math.random() * 0.8 + 0.2
      });
    }
    engineRef.current.stars = stars;
  }, []);

  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') engineRef.current.keys.left = true;
      if (k === 'arrowright' || k === 'd') engineRef.current.keys.right = true;
      if (k === ' ' || k === 'w' || k === 'arrowup') {
        e.preventDefault();
        triggerJump();
      }
      if (k === 'j' || k === 'z') {
        triggerAttack();
      }
      if (k === 'k' || k === 'x') {
        triggerMagic();
      }
      if (k === 'l' || k === 'c' || k === 'shift') {
        triggerDash();
      }
      if (k === 'p' || k === 'escape') {
        setGameState(prev => prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') engineRef.current.keys.left = false;
      if (k === 'arrowright' || k === 'd') engineRef.current.keys.right = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const triggerJump = useCallback(() => {
    const eng = engineRef.current;
    if (eng.jumpCount < 2) {
      if (eng.jumpCount === 0) {
        eng.heroVy = -13.5;
        sound.playJump();
      } else {
        eng.heroVy = -12.5;
        sound.playDoubleJump();
        // Spawn double jump particles
        for (let i = 0; i < 8; i++) {
          eng.particles.push({
            x: eng.heroX,
            y: eng.heroY + 20,
            vx: (Math.random() - 0.5) * 4,
            vy: Math.random() * 2 + 1,
            color: '#38bdf8',
            size: 4,
            life: 20,
            maxLife: 20
          });
        }
      }
      eng.jumpCount++;
      eng.isGrounded = false;
    }
  }, []);

  const triggerAttack = useCallback(() => {
    const eng = engineRef.current;
    if (eng.slashTimer <= 0) {
      eng.slashTimer = 18;
      sound.playSlash();

      // Spawn slash wave projectile
      const dmg = weapon.damage * hero.stats.power;
      eng.projectiles.push({
        x: eng.heroX + 35,
        y: eng.heroY,
        vx: 12,
        vy: 0,
        radius: 22,
        color: weapon.element === 'fire' ? '#f97316' : weapon.element === 'lightning' ? '#eab308' : weapon.element === 'ice' ? '#06b6d4' : '#a855f7',
        damage: dmg,
        isPlayer: true,
        type: 'slash'
      });
    }
  }, [weapon, hero]);

  const triggerMagic = useCallback(() => {
    const eng = engineRef.current;
    if (eng.mana >= 30 && eng.spellCooldown <= 0) {
      eng.mana -= 30;
      eng.spellCooldown = 40;
      sound.playPowerup();

      // Cast 3 homing/forward elemental orbs
      const dmg = weapon.damage * hero.stats.power * 1.5;
      for (let i = -1; i <= 1; i++) {
        eng.projectiles.push({
          x: eng.heroX + 40,
          y: eng.heroY + i * 15,
          vx: 14,
          vy: i * 2.5,
          radius: 18,
          color: '#ec4899',
          damage: dmg,
          isPlayer: true,
          type: 'fire'
        });
      }

      eng.floatingTexts.push({
        id: Math.random(),
        text: hero.specialSkill,
        x: eng.heroX,
        y: eng.heroY - 40,
        color: '#f43f5e',
        size: 16,
        life: 45
      });
    }
  }, [hero, weapon]);

  const triggerDash = useCallback(() => {
    const eng = engineRef.current;
    if (eng.dashCooldown <= 0) {
      eng.dashTimer = 22;
      eng.dashCooldown = 75;
      sound.playDash();

      // Dash particles
      for (let i = 0; i < 15; i++) {
        eng.particles.push({
          x: eng.heroX - 10,
          y: eng.heroY + (Math.random() - 0.5) * 30,
          vx: -Math.random() * 6 - 2,
          vy: (Math.random() - 0.5) * 3,
          color: '#06b6d4',
          size: 5,
          life: 25,
          maxLife: 25
        });
      }
    }
  }, []);

  const startGame = () => {
    const eng = engineRef.current;
    eng.distance = 0;
    eng.speed = 6.5;
    eng.heroX = 140;
    eng.heroY = 340;
    eng.heroVy = 0;
    eng.isGrounded = true;
    eng.jumpCount = 0;
    eng.dashTimer = 0;
    eng.dashCooldown = 0;
    eng.slashTimer = 0;
    eng.spellCooldown = 0;
    eng.hp = hero.stats.health;
    eng.maxHp = hero.stats.health;
    eng.mana = 100;
    eng.isShielded = false;
    eng.magnetTimer = 0;
    eng.score = 0;
    eng.coins = 0;
    eng.diamonds = 0;
    eng.combo = 1;
    eng.enemies = [];
    eng.projectiles = [];
    eng.collectibles = [];
    eng.particles = [];
    eng.floatingTexts = [];
    eng.nextEnemyDist = 400;
    eng.nextCoinDist = 200;
    eng.nextBossDist = 1000;
    eng.bossDefeatedCount = 0;

    setScore(0);
    setCoinsCollected(0);
    setDiamondsCollected(0);
    setDistance(0);
    setHp(hero.stats.health);
    setMana(100);
    setIsShielded(false);
    setBossActive(false);
    setGameState('playing');
    sound.startBgm('cyber_silkroad');
  };

  const handleGameOver = () => {
    const eng = engineRef.current;
    setGameState('gameover');
    sound.playGameOver();

    // Save earned stats
    const finalScore = eng.score;
    const finalCoins = eng.coins;
    const finalDiamonds = eng.diamonds;

    const stats = storage.getStats();
    if (finalScore > stats.runnerHighScore) {
      stats.runnerHighScore = finalScore;
      setHighScore(finalScore);
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    }
    if (eng.distance > stats.runnerMaxDistance) {
      stats.runnerMaxDistance = Math.floor(eng.distance);
    }
    stats.runnerBossesDefeated += eng.bossDefeatedCount;
    stats.totalGamesPlayed += 1;
    storage.saveStats(stats);

    // Update player coins & diamonds & quests
    const updated = storage.addCoinsAndDiamonds(finalCoins, finalDiamonds);

    // Check quests
    const quests = storage.getDailyQuests();
    quests.forEach(q => {
      if (q.targetGame === 'runner' || q.targetGame === 'any') {
        if (q.id === 'quest_run_1000') {
          q.progress += Math.floor(eng.distance);
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
        if (q.id === 'quest_play_games') {
          q.progress += 1;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
      }
    });
    storage.saveDailyQuests(quests);

    // Check achievements
    const achs = storage.getAchievements();
    achs.forEach(a => {
      if (a.id === 'first_run' && eng.distance >= 500) {
        a.progress = Math.min(a.maxProgress, Math.floor(eng.distance));
        if (a.progress >= a.maxProgress) a.isUnlocked = true;
      }
      if (a.id === 'boss_slayer_1' && eng.bossDefeatedCount >= 1) {
        a.progress = 1;
        a.isUnlocked = true;
      }
      if (a.id === 'coin_collector_1000') {
        a.progress = Math.min(a.maxProgress, a.progress + finalCoins);
        if (a.progress >= a.maxProgress) a.isUnlocked = true;
      }
    });
    storage.saveAchievements(achs);

    onUpdateProfile(updated);
  };

  // Main Canvas Game Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const groundY = 380;

    const gameLoop = () => {
      if (gameState === 'playing') {
        const eng = engineRef.current;

        // Increase distance & speed over time
        eng.distance += eng.speed / 10;
        eng.score += Math.floor(eng.speed / 5) * eng.combo;
        eng.speed = Math.min(14, 6.5 + eng.distance / 400);

        // Natural mana regeneration
        if (eng.mana < 100) {
          eng.mana = Math.min(100, eng.mana + 0.15 * hero.stats.magic);
        }

        // Timers
        if (eng.dashTimer > 0) eng.dashTimer--;
        if (eng.dashCooldown > 0) eng.dashCooldown--;
        if (eng.slashTimer > 0) eng.slashTimer--;
        if (eng.spellCooldown > 0) eng.spellCooldown--;
        if (eng.magnetTimer > 0) eng.magnetTimer--;
        if (eng.shake > 0) eng.shake--;

        if (eng.comboTimer > 0) {
          eng.comboTimer--;
          if (eng.comboTimer === 0) eng.combo = 1;
        }

        // Hero Movement Left/Right
        if (eng.keys.left) eng.heroX = Math.max(60, eng.heroX - 5);
        if (eng.keys.right) eng.heroX = Math.min(300, eng.heroX + 5);

        // Hero Gravity & Jump Physics
        eng.heroVy += 0.65; // gravity
        eng.heroY += eng.heroVy;

        if (eng.heroY >= groundY - 40) {
          eng.heroY = groundY - 40;
          eng.heroVy = 0;
          eng.isGrounded = true;
          eng.jumpCount = 0;
        }

        // Spawn Enemies
        if (eng.distance >= eng.nextEnemyDist) {
          eng.nextEnemyDist = eng.distance + Math.random() * 250 + 200;
          const randType = Math.random();
          if (randType < 0.45) {
            eng.enemies.push({
              id: Math.random(),
              x: canvas.width + 50,
              y: groundY - 35,
              width: 38,
              height: 35,
              type: 'ground_crawler',
              hp: 40 + Math.floor(eng.distance / 200) * 10,
              maxHp: 40 + Math.floor(eng.distance / 200) * 10,
              speed: eng.speed + 1.5,
              attackCooldown: 0,
              color: '#ef4444'
            });
          } else if (randType < 0.8) {
            eng.enemies.push({
              id: Math.random(),
              x: canvas.width + 50,
              y: groundY - 110 - Math.random() * 80,
              width: 34,
              height: 30,
              type: 'flying_drone',
              hp: 30 + Math.floor(eng.distance / 200) * 8,
              maxHp: 30 + Math.floor(eng.distance / 200) * 8,
              speed: eng.speed + 1.0,
              attackCooldown: 60,
              color: '#06b6d4'
            });
          } else {
            eng.enemies.push({
              id: Math.random(),
              x: canvas.width + 50,
              y: groundY - 45,
              width: 36,
              height: 45,
              type: 'spear_bot',
              hp: 60 + Math.floor(eng.distance / 200) * 15,
              maxHp: 60 + Math.floor(eng.distance / 200) * 15,
              speed: eng.speed + 0.5,
              attackCooldown: 0,
              color: '#8b5cf6'
            });
          }
        }

        // Spawn Boss every 1000m
        if (eng.distance >= eng.nextBossDist && !eng.enemies.some(e => e.isBoss)) {
          eng.nextBossDist = eng.distance + 1200;
          const bMaxHp = 350 + eng.bossDefeatedCount * 250;
          eng.enemies.push({
            id: Math.random(),
            x: canvas.width + 100,
            y: groundY - 85,
            width: 75,
            height: 85,
            type: 'boss',
            hp: bMaxHp,
            maxHp: bMaxHp,
            speed: eng.speed * 0.85,
            attackCooldown: 60,
            color: '#dc2626',
            isBoss: true,
            bossPhase: 1
          });
          setBossActive(true);
          setBossHp({ current: bMaxHp, max: bMaxHp });
          sound.playPowerup();
        }

        // Spawn Collectibles (Coins / Diamonds / Powerups)
        if (eng.distance >= eng.nextCoinDist) {
          eng.nextCoinDist = eng.distance + Math.random() * 120 + 80;
          const isDiamond = Math.random() < 0.08;
          const isHeart = Math.random() < 0.06;
          const isShield = Math.random() < 0.04;
          const isMagnet = Math.random() < 0.04;

          let type: Collectible['type'] = 'coin';
          if (isDiamond) type = 'diamond';
          else if (isHeart) type = 'heart';
          else if (isShield) type = 'shield';
          else if (isMagnet) type = 'magnet';

          const spawnY = Math.random() < 0.4 ? groundY - 30 : groundY - 100 - Math.random() * 50;

          eng.collectibles.push({
            id: Math.random(),
            x: canvas.width + 40,
            y: spawnY,
            type,
            radius: type === 'diamond' ? 14 : 12
          });
        }

        // Update Projectiles
        for (let i = eng.projectiles.length - 1; i >= 0; i--) {
          const p = eng.projectiles[i];
          p.x += p.vx;
          p.y += p.vy;

          // Remove offscreen
          if (p.x < -50 || p.x > canvas.width + 100 || p.y < -50 || p.y > canvas.height + 50) {
            eng.projectiles.splice(i, 1);
            continue;
          }

          // Player projectile hit enemies
          if (p.isPlayer) {
            for (let j = eng.enemies.length - 1; j >= 0; j--) {
              const enemy = eng.enemies[j];
              const hit = (
                p.x + p.radius > enemy.x &&
                p.x - p.radius < enemy.x + enemy.width &&
                p.y + p.radius > enemy.y &&
                p.y - p.radius < enemy.y + enemy.height
              );

              if (hit) {
                enemy.hp -= p.damage;
                sound.playHit();
                eng.shake = 5;

                // Hit particles
                for (let k = 0; k < 6; k++) {
                  eng.particles.push({
                    x: p.x,
                    y: p.y,
                    vx: (Math.random() - 0.5) * 5,
                    vy: (Math.random() - 0.5) * 5,
                    color: p.color,
                    size: 4,
                    life: 18,
                    maxLife: 18
                  });
                }

                // Floating damage
                eng.floatingTexts.push({
                  id: Math.random(),
                  text: `-${Math.round(p.damage)}`,
                  x: enemy.x + enemy.width / 2,
                  y: enemy.y - 10,
                  color: '#fde047',
                  size: 14,
                  life: 30
                });

                if (enemy.isBoss) {
                  setBossHp({ current: Math.max(0, enemy.hp), max: enemy.maxHp });
                }

                // Remove projectile unless it's piercing plasma
                if (weapon.element !== 'plasma') {
                  eng.projectiles.splice(i, 1);
                }

                // Check enemy death
                if (enemy.hp <= 0) {
                  sound.playEnemyDeath();
                  eng.score += enemy.isBoss ? 2500 : 150;
                  eng.combo = Math.min(10, eng.combo + 1);
                  eng.comboTimer = 180;

                  // Coin drop
                  const coinMult = pet?.coinMultiplier || 1.0;
                  const dropCoins = Math.floor((enemy.isBoss ? 50 : 5) * coinMult);
                  eng.coins += dropCoins;

                  if (enemy.isBoss) {
                    eng.diamonds += 3;
                    eng.bossDefeatedCount += 1;
                    setBossActive(false);
                    sound.playBossDefeated();
                    confetti({ particleCount: 50, spread: 60, origin: { x: 0.7, y: 0.5 } });
                  }

                  // Death explosion particles
                  for (let k = 0; k < (enemy.isBoss ? 35 : 12); k++) {
                    eng.particles.push({
                      x: enemy.x + enemy.width / 2,
                      y: enemy.y + enemy.height / 2,
                      vx: (Math.random() - 0.5) * 8,
                      vy: (Math.random() - 0.5) * 8,
                      color: enemy.color,
                      size: enemy.isBoss ? 6 : 4,
                      life: 30,
                      maxLife: 30
                    });
                  }

                  eng.enemies.splice(j, 1);
                }
                break;
              }
            }
          } else {
            // Enemy projectile hits Player
            const hitHero = (
              p.x + p.radius > eng.heroX - 20 &&
              p.x - p.radius < eng.heroX + 20 &&
              p.y + p.radius > eng.heroY - 30 &&
              p.y - p.radius < eng.heroY + 30
            );

            if (hitHero && eng.dashTimer <= 0) {
              if (eng.isShielded) {
                eng.isShielded = false;
                setIsShielded(false);
                sound.playHit();
              } else {
                eng.hp -= p.damage;
                sound.playHit();
                eng.shake = 10;
              }
              eng.projectiles.splice(i, 1);
              if (eng.hp <= 0) {
                handleGameOver();
              }
            }
          }
        }

        // Update Enemies
        for (let i = eng.enemies.length - 1; i >= 0; i--) {
          const e = eng.enemies[i];
          e.x -= e.speed;

          // Drone / Boss shooting
          if (e.type === 'flying_drone' && e.attackCooldown <= 0) {
            e.attackCooldown = 90;
            eng.projectiles.push({
              x: e.x,
              y: e.y + 15,
              vx: -7,
              vy: 1.5,
              radius: 6,
              color: '#ef4444',
              damage: 15,
              isPlayer: false,
              type: 'laser'
            });
          } else if (e.isBoss && e.attackCooldown <= 0) {
            e.attackCooldown = 70;
            // Boss laser wave
            eng.projectiles.push({
              x: e.x,
              y: e.y + 20,
              vx: -9,
              vy: 0,
              radius: 12,
              color: '#f43f5e',
              damage: 25,
              isPlayer: false,
              type: 'laser'
            });
            eng.projectiles.push({
              x: e.x,
              y: e.y + 45,
              vx: -8,
              vy: 2,
              radius: 10,
              color: '#e11d48',
              damage: 20,
              isPlayer: false,
              type: 'laser'
            });
          }
          if (e.attackCooldown > 0) e.attackCooldown--;

          // Body collision with hero
          const hitHero = (
            e.x < eng.heroX + 22 &&
            e.x + e.width > eng.heroX - 22 &&
            e.y < eng.heroY + 25 &&
            e.y + e.height > eng.heroY - 25
          );

          if (hitHero) {
            if (eng.dashTimer > 0) {
              // Dashing hero slashes through enemy
              e.hp -= 80 * hero.stats.power;
              sound.playHit();
              if (e.hp <= 0) {
                sound.playEnemyDeath();
                eng.score += 200;
                eng.coins += 10;
                eng.enemies.splice(i, 1);
                continue;
              }
            } else {
              // Hero takes damage
              if (eng.isShielded) {
                eng.isShielded = false;
                setIsShielded(false);
                sound.playHit();
                eng.enemies.splice(i, 1);
              } else {
                eng.hp -= 20;
                sound.playHit();
                eng.shake = 12;
                eng.enemies.splice(i, 1);
                if (eng.hp <= 0) {
                  handleGameOver();
                  break;
                }
              }
            }
          }

          // Offscreen check
          if (e.x < -100) {
            if (e.isBoss) setBossActive(false);
            eng.enemies.splice(i, 1);
          }
        }

        // Update Collectibles
        for (let i = eng.collectibles.length - 1; i >= 0; i--) {
          const c = eng.collectibles[i];
          c.x -= eng.speed;

          // Magnet pull
          if (eng.magnetTimer > 0 || (pet && pet.id === 'humo_burgut')) {
            const dx = eng.heroX - c.x;
            const dy = eng.heroY - c.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
            if (dist < 260) {
              c.x += (dx / dist) * 10;
              c.y += (dy / dist) * 10;
            }
          }

          // Hero collects
          const dist = Math.hypot(eng.heroX - c.x, eng.heroY - c.y);
          if (dist < 35) {
            if (c.type === 'coin') {
              sound.playCoin();
              const mult = pet?.coinMultiplier || 1.0;
              eng.coins += Math.floor(1 * mult);
              eng.score += 25 * eng.combo;
            } else if (c.type === 'diamond') {
              sound.playDiamond();
              eng.diamonds += 1;
              eng.score += 200;
            } else if (c.type === 'heart') {
              sound.playPowerup();
              eng.hp = Math.min(eng.maxHp, eng.hp + 40);
            } else if (c.type === 'shield') {
              sound.playPowerup();
              eng.isShielded = true;
              setIsShielded(true);
            } else if (c.type === 'magnet') {
              sound.playPowerup();
              eng.magnetTimer = 300; // 5 seconds
            }

            // Collection sparkle
            for (let k = 0; k < 8; k++) {
              eng.particles.push({
                x: c.x,
                y: c.y,
                vx: (Math.random() - 0.5) * 4,
                vy: (Math.random() - 0.5) * 4,
                color: c.type === 'diamond' ? '#38bdf8' : c.type === 'heart' ? '#f43f5e' : '#eab308',
                size: 3,
                life: 15,
                maxLife: 15
              });
            }

            eng.collectibles.splice(i, 1);
            continue;
          }

          if (c.x < -40) {
            eng.collectibles.splice(i, 1);
          }
        }

        // Update Particles
        for (let i = eng.particles.length - 1; i >= 0; i--) {
          const p = eng.particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.life--;
          if (p.life <= 0) eng.particles.splice(i, 1);
        }

        // Update Floating Texts
        for (let i = eng.floatingTexts.length - 1; i >= 0; i--) {
          const ft = eng.floatingTexts[i];
          ft.y -= 1.2;
          ft.life--;
          if (ft.life <= 0) eng.floatingTexts.splice(i, 1);
        }

        // Sync React HUD state
        setScore(eng.score);
        setCoinsCollected(eng.coins);
        setDiamondsCollected(eng.diamonds);
        setDistance(Math.floor(eng.distance));
        setHp(Math.max(0, eng.hp));
        setMana(eng.mana);
        setCombo(eng.combo);
      }

      /* ---------------- RENDERING CANVAS ---------------- */
      ctx.save();

      // Screen Shake
      const eng = engineRef.current;
      if (eng.shake > 0) {
        ctx.translate((Math.random() - 0.5) * eng.shake * 1.5, (Math.random() - 0.5) * eng.shake * 1.5);
      }

      // Background Sky Gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, canvas.height);
      skyGrad.addColorStop(0, '#020617'); // Dark navy
      skyGrad.addColorStop(0.5, '#0f172a'); // Slate midnight
      skyGrad.addColorStop(1, '#1e1b4b'); // Cyber indigo
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Stars
      ctx.fillStyle = '#ffffff';
      eng.stars.forEach(st => {
        ctx.globalAlpha = st.alpha;
        ctx.fillRect(st.x, st.y, st.s, st.s);
        st.x -= 0.2; // slow parallax
        if (st.x < 0) st.x = canvas.width;
      });
      ctx.globalAlpha = 1.0;

      // Parallax Background: Cyber Samarkand Registan & Minarets Silhouette
      ctx.fillStyle = '#1e1b4b';
      const bgOffset = (eng.distance * 0.4) % 600;
      for (let i = -1; i < 3; i++) {
        const bx = i * 600 - bgOffset;
        // Large Central Dome
        ctx.beginPath();
        ctx.arc(bx + 200, groundY - 60, 90, Math.PI, 0);
        ctx.fill();
        // Minaret Left
        ctx.fillRect(bx + 80, groundY - 180, 24, 180);
        // Minaret Right
        ctx.fillRect(bx + 320, groundY - 180, 24, 180);
        // Registan Arch
        ctx.fillRect(bx + 140, groundY - 130, 120, 130);
      }

      // Midground Neon Grid Lines & Towers
      ctx.fillStyle = '#312e81';
      const midOffset = (eng.distance * 0.8) % 400;
      for (let i = -1; i < 4; i++) {
        const mx = i * 400 - midOffset;
        ctx.fillRect(mx + 50, groundY - 80, 40, 80);
        ctx.fillRect(mx + 150, groundY - 110, 50, 110);
        ctx.fillRect(mx + 280, groundY - 70, 35, 70);
      }

      // Cyber Ground Platform
      const groundGrad = ctx.createLinearGradient(0, groundY, 0, canvas.height);
      groundGrad.addColorStop(0, '#06b6d4');
      groundGrad.addColorStop(0.1, '#0f172a');
      groundGrad.addColorStop(1, '#020617');
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, groundY, canvas.width, canvas.height - groundY);

      // Moving Ground Grid Stripes
      eng.groundOffset = (eng.groundOffset + eng.speed) % 40;
      ctx.strokeStyle = '#0891b2';
      ctx.lineWidth = 2;
      for (let x = -eng.groundOffset; x < canvas.width; x += 40) {
        ctx.beginPath();
        ctx.moveTo(x, groundY);
        ctx.lineTo(x - 30, canvas.height);
        ctx.stroke();
      }

      // Draw Collectibles
      eng.collectibles.forEach(c => {
        ctx.save();
        ctx.translate(c.x, c.y);
        if (c.type === 'coin') {
          ctx.fillStyle = '#eab308';
          ctx.beginPath();
          ctx.arc(0, 0, c.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.strokeStyle = '#ca8a04';
          ctx.lineWidth = 2;
          ctx.stroke();
          ctx.fillStyle = '#713f12';
          ctx.font = 'bold 11px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('UZ', 0, 0);
        } else if (c.type === 'diamond') {
          ctx.fillStyle = '#38bdf8';
          ctx.beginPath();
          ctx.moveTo(0, -c.radius);
          ctx.lineTo(c.radius, 0);
          ctx.lineTo(0, c.radius);
          ctx.lineTo(-c.radius, 0);
          ctx.closePath();
          ctx.fill();
          ctx.strokeStyle = '#0284c7';
          ctx.stroke();
        } else if (c.type === 'heart') {
          ctx.font = '22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('❤️', 0, 0);
        } else if (c.type === 'shield') {
          ctx.font = '22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🛡️', 0, 0);
        } else if (c.type === 'magnet') {
          ctx.font = '22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🧲', 0, 0);
        }
        ctx.restore();
      });

      // Draw Enemies
      eng.enemies.forEach(e => {
        ctx.save();
        ctx.translate(e.x, e.y);

        if (e.isBoss) {
          // Giant Boss Drawing
          ctx.fillStyle = e.color;
          ctx.fillRect(0, 0, e.width, e.height);
          // Boss glowing eyes
          ctx.fillStyle = '#fde047';
          ctx.fillRect(12, 18, 16, 12);
          ctx.fillRect(45, 18, 16, 12);
          // Boss Crown / Horns
          ctx.fillStyle = '#991b1b';
          ctx.beginPath();
          ctx.moveTo(0, 0);
          ctx.lineTo(20, -20);
          ctx.lineTo(38, 0);
          ctx.lineTo(55, -20);
          ctx.lineTo(75, 0);
          ctx.closePath();
          ctx.fill();
        } else if (e.type === 'flying_drone') {
          ctx.fillStyle = e.color;
          ctx.beginPath();
          ctx.arc(e.width / 2, e.height / 2, e.width / 2, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#ef4444';
          ctx.fillRect(e.width / 2 - 4, e.height / 2 - 4, 8, 8);
          // Drone wings
          ctx.strokeStyle = '#cbd5e1';
          ctx.lineWidth = 3;
          ctx.strokeRect(-5, e.height / 2 - 2, e.width + 10, 4);
        } else {
          // Ground Crawler / Bot
          ctx.fillStyle = e.color;
          ctx.fillRect(0, 0, e.width, e.height);
          ctx.fillStyle = '#fef08a';
          ctx.fillRect(6, 8, 8, 8);
        }

        // Enemy HP bar
        if (e.hp < e.maxHp && !e.isBoss) {
          ctx.fillStyle = '#334155';
          ctx.fillRect(0, -10, e.width, 4);
          ctx.fillStyle = '#22c55e';
          ctx.fillRect(0, -10, (e.hp / e.maxHp) * e.width, 4);
        }

        ctx.restore();
      });

      // Draw Projectiles
      eng.projectiles.forEach(p => {
        ctx.save();
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw Pet (if equipped)
      if (pet) {
        ctx.save();
        const petX = eng.heroX - 35;
        const petY = eng.heroY - 25 + Math.sin(Date.now() / 200) * 8;
        ctx.font = '24px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(pet.emoji, petX, petY);
        ctx.restore();
      }

      // Draw Hero
      ctx.save();
      ctx.translate(eng.heroX, eng.heroY);

      // Dash Ghost Effect
      if (eng.dashTimer > 0) {
        ctx.fillStyle = 'rgba(6, 182, 212, 0.4)';
        ctx.fillRect(-22, -30, 44, 60);
      }

      // Shield Bubble
      if (eng.isShielded) {
        ctx.strokeStyle = '#38bdf8';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.arc(0, 0, 36, 0, Math.PI * 2);
        ctx.stroke();
      }

      // Hero Body (Avatar Emoji or Styled Cyber Knight)
      ctx.font = '38px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(hero.avatar, 0, 0);

      // Sword Slash Animation Wave
      if (eng.slashTimer > 0) {
        ctx.strokeStyle = weapon.element === 'fire' ? '#f97316' : weapon.element === 'lightning' ? '#eab308' : '#38bdf8';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.arc(20, 0, 32, -Math.PI / 3, Math.PI / 3);
        ctx.stroke();
      }

      ctx.restore();

      // Draw Particles
      eng.particles.forEach(p => {
        ctx.save();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / p.maxLife;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw Floating Texts
      eng.floatingTexts.forEach(ft => {
        ctx.save();
        ctx.fillStyle = ft.color;
        ctx.font = `bold ${ft.size}px 'Outfit', sans-serif`;
        ctx.textAlign = 'center';
        ctx.globalAlpha = Math.min(1, ft.life / 20);
        ctx.fillText(ft.text, ft.x, ft.y);
        ctx.restore();
      });

      ctx.restore();

      animId = requestAnimationFrame(gameLoop);
    };

    animId = requestAnimationFrame(gameLoop);
    return () => cancelAnimationFrame(animId);
  }, [gameState, hero, weapon, pet]);

  const toggleSound = () => {
    const s = sound.toggleSfxMute();
    sound.toggleBgmMute();
    setIsMuted(s);
  };

  return (
    <div className="relative w-full max-w-5xl mx-auto flex flex-col items-center">
      {/* Top Game Bar */}
      <div className="w-full flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 backdrop-blur-md shadow-2xl">
        <button
          onClick={onBackToHub}
          className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition text-xs sm:text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.backToHub}</span>
        </button>

        {/* Live Counters */}
        <div className="flex items-center gap-3 sm:gap-6 text-xs sm:text-sm font-bold">
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 font-pixel">{score}</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-amber-400 font-bold">🪙 {coinsCollected}</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-cyan-400 font-bold">💎 {diamondsCollected}</span>
          </div>
          <div className="hidden md:flex items-center gap-1.5 text-slate-400">
            <span>{distance} m</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Canvas Area Container */}
      <div className="relative w-full aspect-[16/9] max-h-[540px] bg-slate-950 rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-2xl">
        <canvas
          ref={canvasRef}
          width={960}
          height={540}
          className="w-full h-full object-cover block"
        />

        {/* HUD Bars (HP & Mana) */}
        {gameState === 'playing' && (
          <div className="absolute top-4 left-4 flex flex-col gap-2 z-10 pointer-events-none">
            {/* HP Bar */}
            <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-rose-500/30">
              <Heart className="w-4 h-4 text-rose-500 fill-rose-500" />
              <div className="w-28 sm:w-36 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-rose-500 to-red-600 transition-all duration-200"
                  style={{ width: `${Math.max(0, (hp / hero.stats.health) * 100)}%` }}
                />
              </div>
              <span className="text-xs font-bold text-rose-300 font-mono">{Math.round(hp)}</span>
            </div>

            {/* Mana Bar */}
            <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-cyan-500/30">
              <Zap className="w-4 h-4 text-cyan-400 fill-cyan-400" />
              <div className="w-28 sm:w-36 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-200"
                  style={{ width: `${Math.max(0, mana)}%` }}
                />
              </div>
              <span className="text-xs font-bold text-cyan-300 font-mono">{Math.round(mana)}</span>
            </div>

            {/* Combo Badge */}
            {combo > 1 && (
              <div className="mt-1 flex items-center gap-1 px-3 py-1 bg-gradient-to-r from-amber-500 to-red-500 text-white font-extrabold text-xs sm:text-sm rounded-lg shadow-lg animate-pulse">
                <Sparkles className="w-4 h-4" />
                <span>{t.combo} x{combo}!</span>
              </div>
            )}
          </div>
        )}

        {/* Boss Alert Header */}
        {bossActive && gameState === 'playing' && (
          <div className="absolute top-4 right-4 max-w-xs bg-red-950/90 border border-red-500/60 p-3 rounded-2xl z-10 backdrop-blur-md shadow-2xl animate-pulse">
            <div className="flex items-center gap-2 text-red-400 font-bold text-xs uppercase tracking-wider mb-1">
              <Flame className="w-4 h-4 text-red-500" />
              <span>{t.runnerBossWarning}</span>
            </div>
            <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-red-800">
              <div
                className="h-full bg-gradient-to-r from-red-600 to-yellow-500 transition-all duration-200"
                style={{ width: `${(bossHp.current / bossHp.max) * 100}%` }}
              />
            </div>
          </div>
        )}

        {/* Overlay: Menu / Start */}
        {gameState === 'menu' && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="text-5xl sm:text-6xl mb-3 animate-float">{hero.avatar}</div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-500 mb-2 font-russo tracking-wide">
              {t.game1Title}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-md mb-6 leading-relaxed">
              {t.game1Desc}
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
              <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300">
                <span className="text-yellow-400 font-bold">{t.highScore}:</span> {highScore}
              </div>
              <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300">
                <span className="text-cyan-400 font-bold">{hero.name}:</span> {weapon.name}
              </div>
            </div>

            <button
              onClick={startGame}
              className="px-8 py-3.5 bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 font-black text-base sm:text-lg rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition flex items-center gap-3 glow-gold"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>{t.playNow}</span>
            </button>
          </div>
        )}

        {/* Overlay: Game Over */}
        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <h2 className="text-3xl sm:text-5xl font-black text-rose-500 mb-2 font-russo">
              {t.gameOver}
            </h2>
            <p className="text-slate-400 text-sm mb-6 font-cyber">
              {distance} metr masofada jasorat ko'rsatdingiz!
            </p>

            <div className="grid grid-cols-3 gap-3 max-w-md w-full mb-6">
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.score}</div>
                <div className="text-lg font-bold text-yellow-400 font-pixel">{score}</div>
              </div>
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.coins}</div>
                <div className="text-lg font-bold text-amber-400">+{coinsCollected} 🪙</div>
              </div>
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.diamonds}</div>
                <div className="text-lg font-bold text-cyan-400">+{diamondsCollected} 💎</div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={startGame}
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold rounded-xl shadow-lg hover:scale-105 transition flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.restart}</span>
              </button>
              <button
                onClick={onBackToHub}
                className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition"
              >
                {t.backToHub}
              </button>
            </div>
          </div>
        )}

        {/* Overlay: Pause */}
        {gameState === 'paused' && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <h2 className="text-3xl font-extrabold text-cyan-400 mb-4 font-russo">{t.pause}</h2>
            <div className="flex gap-4">
              <button
                onClick={() => setGameState('playing')}
                className="px-6 py-2.5 bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold rounded-xl"
              >
                {t.resume}
              </button>
              <button
                onClick={startGame}
                className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl"
              >
                {t.restart}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Mobile / Screen Action Touch Controls */}
      <div className="w-full mt-4 grid grid-cols-2 sm:grid-cols-4 gap-2.5">
        <button
          onPointerDown={triggerJump}
          className="p-3.5 bg-slate-900/90 border border-slate-800 hover:border-cyan-500 text-slate-200 active:bg-cyan-950 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-lg">⬆️</span>
          <span className="text-xs font-bold text-cyan-400 mt-1">SAKRASH (Space / W)</span>
        </button>

        <button
          onPointerDown={triggerAttack}
          className="p-3.5 bg-slate-900/90 border border-slate-800 hover:border-amber-500 text-slate-200 active:bg-amber-950 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-lg">🗡️</span>
          <span className="text-xs font-bold text-amber-400 mt-1">QILICH ZARBASI (J)</span>
        </button>

        <button
          onPointerDown={triggerMagic}
          className="p-3.5 bg-slate-900/90 border border-slate-800 hover:border-pink-500 text-slate-200 active:bg-pink-950 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-lg">⚡</span>
          <span className="text-xs font-bold text-pink-400 mt-1">SEHRLI HUJUM (K)</span>
        </button>

        <button
          onPointerDown={triggerDash}
          className="p-3.5 bg-slate-900/90 border border-slate-800 hover:border-blue-500 text-slate-200 active:bg-blue-950 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-lg">💨</span>
          <span className="text-xs font-bold text-blue-400 mt-1">DASH / QALQON (L)</span>
        </button>
      </div>

      {/* Keyboard Controls Guide */}
      <div className="w-full mt-3 p-3 bg-slate-900/50 border border-slate-800/80 rounded-xl text-center text-xs text-slate-400">
        <span className="text-slate-300 font-bold">{t.controls}: </span>
        {t.runnerControls}
      </div>
    </div>
  );
};
