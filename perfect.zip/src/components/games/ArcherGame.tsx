import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { 
  Play, RotateCcw, Volume2, VolumeX, Trophy, ArrowLeft,
  Shield, Flame, Snowflake, Zap
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ArcherGameProps {
  profile: PlayerProfile;
  language: Language;
  onUpdateProfile: (profile: PlayerProfile) => void;
  onBackToHub: () => void;
}

interface Arrow {
  x: number;
  y: number;
  vx: number;
  vy: number;
  type: 'normal' | 'fire' | 'ice' | 'multi';
  damage: number;
  color: string;
}

interface Invader {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  hp: number;
  maxHp: number;
  speed: number;
  type: 'drone' | 'crawler' | 'mech_boss';
  color: string;
  isFrozen: number;
}

interface ArcherParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
}

export const ArcherGame: React.FC<ArcherGameProps> = ({
  language,
  onUpdateProfile,
  onBackToHub
}) => {
  const t = getTranslation(language);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameover'>('menu');
  const [score, setScore] = useState(0);
  const [wave, setWave] = useState(1);
  const [gateHp, setGateHp] = useState(100);
  const [selectedArrowType, setSelectedArrowType] = useState<'normal' | 'fire' | 'ice' | 'multi'>('normal');
  const [fireCooldown, setFireCooldown] = useState(0);
  const [iceCooldown, setIceCooldown] = useState(0);
  const [multiCooldown, setMultiCooldown] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  const engineRef = useRef({
    arrows: [] as Arrow[],
    invaders: [] as Invader[],
    particles: [] as ArcherParticle[],
    gateHp: 100,
    score: 0,
    wave: 1,
    waveEnemiesLeft: 12,
    waveSpawnTimer: 0,
    killsCount: 0,
    coinsEarned: 0,
    diamondsEarned: 0,
    shake: 0,
    bowAngle: 0
  });

  useEffect(() => {
    const stats = storage.getStats();
    setHighScore(stats.archerHighScore);
    sound.startBgm('retro_arcade');

    return () => {
      sound.stopBgm();
    };
  }, []);

  const startGame = () => {
    const eng = engineRef.current;
    eng.arrows = [];
    eng.invaders = [];
    eng.particles = [];
    eng.gateHp = 100;
    eng.score = 0;
    eng.wave = 1;
    eng.waveEnemiesLeft = 12;
    eng.waveSpawnTimer = 30;
    eng.killsCount = 0;
    eng.coinsEarned = 0;
    eng.diamondsEarned = 0;

    setScore(0);
    setWave(1);
    setGateHp(100);
    setSelectedArrowType('normal');
    setFireCooldown(0);
    setIceCooldown(0);
    setMultiCooldown(0);
    setGameState('playing');
    sound.startBgm('retro_arcade');
  };

  const handleGameOver = useCallback(() => {
    const eng = engineRef.current;
    setGameState('gameover');
    sound.playGameOver();

    const finalScore = eng.score;
    const finalCoins = eng.coinsEarned + eng.wave * 25;
    const finalDiamonds = eng.diamondsEarned + Math.floor(eng.wave / 3);

    const stats = storage.getStats();
    if (finalScore > stats.archerHighScore) {
      stats.archerHighScore = finalScore;
      setHighScore(finalScore);
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    }
    stats.archerMaxWave = Math.max(stats.archerMaxWave, eng.wave);
    stats.totalGamesPlayed += 1;
    storage.saveStats(stats);

    const updated = storage.addCoinsAndDiamonds(finalCoins, finalDiamonds);

    // Quests check
    const quests = storage.getDailyQuests();
    quests.forEach(q => {
      if (q.targetGame === 'archer' || q.targetGame === 'any') {
        if (q.id === 'quest_archer_kills') {
          q.progress += eng.killsCount;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
        if (q.id === 'quest_play_games') {
          q.progress += 1;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
      }
    });
    storage.saveDailyQuests(quests);

    // Achievements check
    const achs = storage.getAchievements();
    achs.forEach(a => {
      if (a.id === 'archer_wave_5' && eng.wave >= 5) {
        a.progress = Math.min(a.maxProgress, eng.wave);
        if (a.progress >= a.maxProgress) a.isUnlocked = true;
      }
    });
    storage.saveAchievements(achs);

    onUpdateProfile(updated);
  }, [onUpdateProfile]);

  const shootArrowAt = (targetX: number, targetY: number) => {
    const eng = engineRef.current;
    const bowX = 80;
    const bowY = 270;

    const dx = targetX - bowX;
    const dy = targetY - bowY;
    const angle = Math.atan2(dy, dx);
    eng.bowAngle = angle;

    const speed = 16;
    sound.playBowShoot();

    if (selectedArrowType === 'multi') {
      if (multiCooldown > 0) return;
      setMultiCooldown(180);
      for (let offset = -0.25; offset <= 0.25; offset += 0.125) {
        eng.arrows.push({
          x: bowX,
          y: bowY,
          vx: Math.cos(angle + offset) * speed,
          vy: Math.sin(angle + offset) * speed,
          type: 'multi',
          damage: 40,
          color: '#eab308'
        });
      }
      setSelectedArrowType('normal');
    } else if (selectedArrowType === 'fire') {
      if (fireCooldown > 0) return;
      setFireCooldown(150);
      eng.arrows.push({
        x: bowX,
        y: bowY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        type: 'fire',
        damage: 85,
        color: '#f97316'
      });
      setSelectedArrowType('normal');
    } else if (selectedArrowType === 'ice') {
      if (iceCooldown > 0) return;
      setIceCooldown(150);
      eng.arrows.push({
        x: bowX,
        y: bowY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        type: 'ice',
        damage: 45,
        color: '#06b6d4'
      });
      setSelectedArrowType('normal');
    } else {
      eng.arrows.push({
        x: bowX,
        y: bowY,
        vx: Math.cos(angle) * speed,
        vy: Math.sin(angle) * speed,
        type: 'normal',
        damage: 35,
        color: '#38bdf8'
      });
    }
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (gameState !== 'playing') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;

    const x = (e.clientX - rect.left) * scaleX;
    const y = (e.clientY - rect.top) * scaleY;
    shootArrowAt(x, y);
  };

  // Canvas Main Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const bowX = 80;
    const bowY = 270;
    const gateX = 120;

    const loop = () => {
      if (gameState === 'playing') {
        const eng = engineRef.current;

        // Wave Spawning
        eng.waveSpawnTimer--;
        if (eng.waveSpawnTimer <= 0 && eng.waveEnemiesLeft > 0) {
          eng.waveEnemiesLeft--;
          eng.waveSpawnTimer = Math.max(25, 60 - eng.wave * 3);

          const isBoss = eng.waveEnemiesLeft === 0 && eng.wave % 3 === 0;
          const isDrone = Math.random() < 0.6;

          const spawnY = isDrone ? Math.random() * 280 + 80 : 360 + Math.random() * 80;
          const hpBase = isBoss ? 450 + eng.wave * 120 : (isDrone ? 35 + eng.wave * 12 : 60 + eng.wave * 18);

          eng.invaders.push({
            id: Math.random(),
            x: canvas.width + 40,
            y: spawnY,
            width: isBoss ? 64 : 36,
            height: isBoss ? 64 : 36,
            hp: hpBase,
            maxHp: hpBase,
            speed: isBoss ? 0.8 : (isDrone ? 1.8 + Math.random() * 0.8 : 1.2),
            type: isBoss ? 'mech_boss' : isDrone ? 'drone' : 'crawler',
            color: isBoss ? '#dc2626' : isDrone ? '#8b5cf6' : '#ea580c',
            isFrozen: 0
          });
        }

        // Wave Completion check
        if (eng.waveEnemiesLeft === 0 && eng.invaders.length === 0) {
          eng.wave++;
          eng.waveEnemiesLeft = 12 + eng.wave * 3;
          eng.waveSpawnTimer = 60;
          eng.diamondsEarned += 1;
          sound.playVictory();
          setWave(eng.wave);
          confetti({ particleCount: 35, spread: 60, origin: { x: 0.5, y: 0.4 } });
        }

        // Update Arrows
        for (let i = eng.arrows.length - 1; i >= 0; i--) {
          const a = eng.arrows[i];
          a.x += a.vx;
          a.y += a.vy;

          // Out of bounds
          if (a.x > canvas.width + 50 || a.y < -50 || a.y > canvas.height + 50) {
            eng.arrows.splice(i, 1);
            continue;
          }

          // Hit Invaders check
          for (let j = eng.invaders.length - 1; j >= 0; j--) {
            const inv = eng.invaders[j];
            const hit = (
              a.x > inv.x - inv.width / 2 &&
              a.x < inv.x + inv.width / 2 &&
              a.y > inv.y - inv.height / 2 &&
              a.y < inv.y + inv.height / 2
            );

            if (hit) {
              sound.playHit();
              inv.hp -= a.damage;

              // Ice freeze effect
              if (a.type === 'ice') {
                inv.isFrozen = 120; // 2 seconds frozen
              }

              // Fire bomb AOE explosion
              if (a.type === 'fire') {
                sound.playExplosion();
                eng.invaders.forEach(other => {
                  const d = Math.hypot(other.x - a.x, other.y - a.y);
                  if (d < 120) {
                    other.hp -= 45;
                  }
                });
              }

              // Hit particles
              for (let k = 0; k < 6; k++) {
                eng.particles.push({
                  x: a.x,
                  y: a.y,
                  vx: (Math.random() - 0.5) * 5,
                  vy: (Math.random() - 0.5) * 5,
                  color: a.color,
                  size: 3,
                  life: 15
                });
              }

              eng.arrows.splice(i, 1);

              // Invader death check
              if (inv.hp <= 0) {
                sound.playEnemyDeath();
                eng.score += inv.type === 'mech_boss' ? 500 : 50;
                eng.killsCount++;
                eng.coinsEarned += inv.type === 'mech_boss' ? 25 : 3;

                for (let k = 0; k < 12; k++) {
                  eng.particles.push({
                    x: inv.x,
                    y: inv.y,
                    vx: (Math.random() - 0.5) * 7,
                    vy: (Math.random() - 0.5) * 7,
                    color: inv.color,
                    size: 4,
                    life: 25
                  });
                }

                eng.invaders.splice(j, 1);
              }
              break;
            }
          }
        }

        // Update Invaders Movement & Gate Attack
        for (let i = eng.invaders.length - 1; i >= 0; i--) {
          const inv = eng.invaders[i];
          if (inv.isFrozen > 0) {
            inv.isFrozen--;
          } else {
            inv.x -= inv.speed;
          }

          // Reach Fortress Gate -> Deal Damage
          if (inv.x <= gateX + 20) {
            eng.gateHp -= inv.type === 'mech_boss' ? 30 : 10;
            eng.shake = 10;
            sound.playHit();
            eng.invaders.splice(i, 1);

            if (eng.gateHp <= 0) {
              handleGameOver();
              break;
            }
          }
        }

        // Update Particles
        for (let i = eng.particles.length - 1; i >= 0; i--) {
          const p = eng.particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.life--;
          if (p.life <= 0) eng.particles.splice(i, 1);
        }

        // Sync React HUD
        setScore(eng.score);
        setGateHp(Math.max(0, eng.gateHp));
        if (fireCooldown > 0) setFireCooldown(prev => prev - 1);
        if (iceCooldown > 0) setIceCooldown(prev => prev - 1);
        if (multiCooldown > 0) setMultiCooldown(prev => prev - 1);
      }

      /* ---------------- RENDERING CANVAS ---------------- */
      ctx.save();

      // Screen Shake
      if (engineRef.current.shake > 0) {
        ctx.translate((Math.random() - 0.5) * engineRef.current.shake, (Math.random() - 0.5) * engineRef.current.shake);
        engineRef.current.shake--;
      }

      // Background Sky & Desert Night
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Distant Cyber Pyramids / Dunes
      ctx.fillStyle = '#1e1b4b';
      ctx.beginPath();
      ctx.moveTo(300, 380);
      ctx.lineTo(500, 180);
      ctx.lineTo(700, 380);
      ctx.fill();

      // Fortress Wall & Tower Gate on Left
      ctx.fillStyle = '#334155';
      ctx.fillRect(0, 0, gateX, canvas.height);
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(gateX - 6, 0, 6, canvas.height);

      // Archer Turret
      ctx.save();
      ctx.translate(bowX, bowY);
      ctx.rotate(engineRef.current.bowAngle);
      ctx.fillStyle = '#fde047';
      ctx.fillRect(-15, -6, 35, 12);
      ctx.strokeStyle = '#38bdf8';
      ctx.lineWidth = 3;
      ctx.beginPath();
      ctx.arc(10, 0, 18, -Math.PI / 2, Math.PI / 2);
      ctx.stroke();
      ctx.restore();

      // Draw Invaders
      engineRef.current.invaders.forEach(inv => {
        ctx.save();
        ctx.translate(inv.x, inv.y);

        if (inv.type === 'mech_boss') {
          ctx.font = '54px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🤖', 0, 0);
        } else if (inv.type === 'drone') {
          ctx.font = '32px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🛸', 0, 0);
        } else {
          ctx.font = '32px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🕷️', 0, 0);
        }

        // Ice frozen overlay
        if (inv.isFrozen > 0) {
          ctx.fillStyle = 'rgba(6, 182, 212, 0.5)';
          ctx.beginPath();
          ctx.arc(0, 0, inv.width / 2 + 5, 0, Math.PI * 2);
          ctx.fill();
        }

        // HP bar
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(-inv.width / 2, -inv.height / 2 - 10, inv.width, 4);
        ctx.fillStyle = '#22c55e';
        ctx.fillRect(-inv.width / 2, -inv.height / 2 - 10, (inv.hp / inv.maxHp) * inv.width, 4);

        ctx.restore();
      });

      // Draw Arrows
      engineRef.current.arrows.forEach(a => {
        ctx.save();
        ctx.fillStyle = a.color;
        ctx.beginPath();
        ctx.arc(a.x, a.y, 4, 0, Math.PI * 2);
        ctx.fill();

        // Laser trail
        ctx.strokeStyle = a.color;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(a.x, a.y);
        ctx.lineTo(a.x - a.vx * 1.5, a.y - a.vy * 1.5);
        ctx.stroke();
        ctx.restore();
      });

      // Draw Particles
      engineRef.current.particles.forEach(p => {
        ctx.save();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / 25;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [gameState, handleGameOver, fireCooldown, iceCooldown, multiCooldown]);

  const toggleSound = () => {
    const s = sound.toggleSfxMute();
    sound.toggleBgmMute();
    setIsMuted(s);
  };

  return (
    <div className="relative w-full max-w-5xl mx-auto flex flex-col items-center">
      {/* Top Game Bar */}
      <div className="w-full flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 backdrop-blur-md shadow-2xl">
        <button
          onClick={onBackToHub}
          className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition text-xs sm:text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.backToHub}</span>
        </button>

        {/* Live HUD Dashboard */}
        <div className="flex items-center gap-3 sm:gap-6 text-xs sm:text-sm font-bold">
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 font-pixel">{score}</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-cyan-400 font-bold">{t.wave}:</span>
            <span className="text-white font-mono text-base">{wave}</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span className="text-emerald-400 font-mono">{gateHp}%</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Canvas Area Container */}
      <div className="relative w-full aspect-[16/9] max-h-[540px] bg-slate-950 rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-2xl">
        <canvas
          ref={canvasRef}
          width={960}
          height={540}
          onPointerDown={handlePointerDown}
          className="w-full h-full object-cover block cursor-crosshair touch-none"
        />

        {/* Overlay: Menu / Start */}
        {gameState === 'menu' && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="text-6xl mb-3 animate-float">🏹🏰⚡</div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-500 mb-2 font-russo tracking-wide">
              {t.game4Title}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-md mb-6 leading-relaxed">
              {t.game4Desc}
            </p>

            <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 mb-6">
              <span className="text-yellow-400 font-bold">{t.highScore}:</span> {highScore}
            </div>

            <button
              onClick={startGame}
              className="px-8 py-3.5 bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-base sm:text-lg rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition flex items-center gap-3 glow-cyan"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>{t.playNow}</span>
            </button>
          </div>
        )}

        {/* Overlay: Game Over */}
        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <h2 className="text-3xl sm:text-5xl font-black text-rose-500 mb-2 font-russo">
              {t.gameOver}
            </h2>
            <p className="text-slate-400 text-sm mb-6 font-cyber">
              {wave}-to'lqin mezonigacha qal'ani himoya qildingiz!
            </p>

            <div className="grid grid-cols-2 gap-3 max-w-xs w-full mb-6">
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.score}</div>
                <div className="text-lg font-bold text-yellow-400 font-pixel">{score}</div>
              </div>
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.wave}</div>
                <div className="text-lg font-bold text-cyan-400">{wave}</div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={startGame}
                className="px-6 py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold rounded-xl shadow-lg hover:scale-105 transition flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.restart}</span>
              </button>
              <button
                onClick={onBackToHub}
                className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition"
              >
                {t.backToHub}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Special Arrows Selection Bar */}
      {gameState === 'playing' && (
        <div className="w-full mt-4 grid grid-cols-4 gap-2.5">
          <button
            onClick={() => setSelectedArrowType('normal')}
            className={`p-3 rounded-2xl flex flex-col items-center justify-center transition border ${
              selectedArrowType === 'normal'
                ? 'bg-cyan-950/80 border-cyan-400 shadow-lg glow-cyan'
                : 'bg-slate-900/80 border-slate-800 text-slate-400'
            }`}
          >
            <Zap className="w-5 h-5 text-cyan-400 mb-1" />
            <span className="text-xs font-bold text-slate-200">Oddiy O'q</span>
          </button>

          <button
            onClick={() => setSelectedArrowType('fire')}
            disabled={fireCooldown > 0}
            className={`p-3 rounded-2xl flex flex-col items-center justify-center transition border ${
              fireCooldown > 0 ? 'opacity-40 cursor-not-allowed bg-slate-900' :
              selectedArrowType === 'fire'
                ? 'bg-orange-950/80 border-orange-400 shadow-lg glow-gold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400'
            }`}
          >
            <Flame className="w-5 h-5 text-orange-400 mb-1" />
            <span className="text-xs font-bold text-slate-200">Olovli Bomba</span>
          </button>

          <button
            onClick={() => setSelectedArrowType('ice')}
            disabled={iceCooldown > 0}
            className={`p-3 rounded-2xl flex flex-col items-center justify-center transition border ${
              iceCooldown > 0 ? 'opacity-40 cursor-not-allowed bg-slate-900' :
              selectedArrowType === 'ice'
                ? 'bg-blue-950/80 border-blue-400 shadow-lg glow-cyan'
                : 'bg-slate-900/80 border-slate-800 text-slate-400'
            }`}
          >
            <Snowflake className="w-5 h-5 text-cyan-400 mb-1" />
            <span className="text-xs font-bold text-slate-200">Muzlatish</span>
          </button>

          <button
            onClick={() => setSelectedArrowType('multi')}
            disabled={multiCooldown > 0}
            className={`p-3 rounded-2xl flex flex-col items-center justify-center transition border ${
              multiCooldown > 0 ? 'opacity-40 cursor-not-allowed bg-slate-900' :
              selectedArrowType === 'multi'
                ? 'bg-yellow-950/80 border-yellow-400 shadow-lg glow-gold'
                : 'bg-slate-900/80 border-slate-800 text-slate-400'
            }`}
          >
            <Zap className="w-5 h-5 text-yellow-400 mb-1" />
            <span className="text-xs font-bold text-slate-200">5x Ko'p O'q</span>
          </button>
        </div>
      )}

      {/* Guide */}
      <div className="w-full mt-3 p-3 bg-slate-900/50 border border-slate-800/80 rounded-xl text-center text-xs text-slate-400">
        <span className="text-slate-300 font-bold">{t.controls}: </span>
        {t.archerControls}
      </div>
    </div>
  );
};
