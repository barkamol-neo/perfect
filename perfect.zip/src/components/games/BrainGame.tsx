import React, { useState, useEffect, useRef, useCallback } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { 
  Trophy, ArrowLeft, Zap, Brain, Calculator, HelpCircle,
  RotateCcw, Volume2, VolumeX
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface BrainGameProps {
  profile: PlayerProfile;
  language: Language;
  onUpdateProfile: (profile: PlayerProfile) => void;
  onBackToHub: () => void;
}

type BrainMode = 'reflex' | 'memory' | 'math' | 'quiz';

const QUIZ_QUESTIONS = [
  {
    q: "Samarqanddagi mashhur Registon maydonida nechta madrasa bor?",
    options: ["2 ta", "3 ta (Ulug'bek, Tillakori, Sherdor)", "4 ta", "1 ta"],
    correct: 1
  },
  {
    q: "O'zbek xalq og'zaki ijodidagi afsonaviy bahodir kim?",
    options: ["Alpomish", "Sindbod", "Robin Gud", "Knyaz Igor"],
    correct: 0
  },
  {
    q: "Algoritm so'zi qaysi buyuk alloma nomidan kelib chiqqan?",
    options: ["Ibn Sino", "Al-Xorazmiy", "Mirzo Ulug'bek", "Abu Rayhon Beruniy"],
    correct: 1
  },
  {
    q: "Toshkent teleminorasining balandligi qancha?",
    options: ["250 metr", "375 metr", "500 metr", "180 metr"],
    correct: 1
  },
  {
    q: "Quyosh sistemasidagi eng katta sayyora qaysi?",
    options: ["Mars", "Venera", "Yupiter", "Saturn"],
    correct: 2
  },
  {
    q: "Kompyuterning miyasi hisoblangan asosiy qurilma nima?",
    options: ["Monitor", "RAM", "Protsessor (CPU)", "Klaviatura"],
    correct: 2
  }
];

export const BrainGame: React.FC<BrainGameProps> = ({
  language,
  onUpdateProfile,
  onBackToHub
}) => {
  const t = getTranslation(language);

  const [mode, setMode] = useState<BrainMode | null>(null);
  const [score, setScore] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [isGameOver, setIsGameOver] = useState(false);
  const [isMuted, setIsMuted] = useState(false);

  // Mode 1: Reflex States
  const [reflexState, setReflexState] = useState<'idle' | 'waiting' | 'ready' | 'result' | 'early'>('idle');
  const [reflexMs, setReflexMs] = useState<number | null>(null);
  const reflexStartRef = useRef<number>(0);
  const reflexTimeoutRef = useRef<number | null>(null);

  // Mode 2: Memory Matrix States
  const [matrixPattern, setMatrixPattern] = useState<number[]>([]);
  const [playerInput, setPlayerInput] = useState<number[]>([]);
  const [isShowingPattern, setIsShowingPattern] = useState(false);
  const [activeTile, setActiveTile] = useState<number | null>(null);
  const [matrixLevel, setMatrixLevel] = useState(1);

  // Mode 3: Math Blitz States
  const [mathQuestion, setMathQuestion] = useState({ text: '', answer: 0, options: [] as number[] });
  const [mathTimer, setMathTimer] = useState(30);

  // Mode 4: Quiz States
  const [quizIdx, setQuizIdx] = useState(0);

  useEffect(() => {
    const stats = storage.getStats();
    setHighScore(stats.brainHighScore);
    sound.startBgm('retro_arcade');

    return () => {
      sound.stopBgm();
      if (reflexTimeoutRef.current) clearTimeout(reflexTimeoutRef.current);
    };
  }, []);

  const finishGame = useCallback((finalScore: number) => {
    setIsGameOver(true);
    sound.playVictory();

    const stats = storage.getStats();
    if (finalScore > stats.brainHighScore) {
      stats.brainHighScore = finalScore;
      setHighScore(finalScore);
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    }
    stats.totalGamesPlayed += 1;
    storage.saveStats(stats);

    const coinsEarned = Math.floor(finalScore / 2);
    const updated = storage.addCoinsAndDiamonds(coinsEarned, finalScore >= 100 ? 3 : 0);

    // Achievements check
    const achs = storage.getAchievements();
    achs.forEach(a => {
      if (a.id === 'brain_score_100' && finalScore >= 100) {
        a.progress = Math.min(a.maxProgress, finalScore);
        if (a.progress >= a.maxProgress) a.isUnlocked = true;
      }
    });
    storage.saveAchievements(achs);

    onUpdateProfile(updated);
  }, [onUpdateProfile]);

  /* ---------------- REFLEX MODE ---------------- */
  const startReflexRound = () => {
    setReflexState('waiting');
    setReflexMs(null);

    const delay = Math.random() * 2500 + 1500;
    if (reflexTimeoutRef.current) clearTimeout(reflexTimeoutRef.current);

    reflexTimeoutRef.current = window.setTimeout(() => {
      setReflexState('ready');
      reflexStartRef.current = performance.now();
      sound.playPop();
    }, delay);
  };

  const handleReflexTap = () => {
    if (reflexState === 'waiting') {
      if (reflexTimeoutRef.current) clearTimeout(reflexTimeoutRef.current);
      setReflexState('early');
      sound.playWrong();
    } else if (reflexState === 'ready') {
      const ms = Math.round(performance.now() - reflexStartRef.current);
      setReflexMs(ms);
      setReflexState('result');
      sound.playCorrect();

      const earned = Math.max(10, Math.floor(600 - ms));
      const newScore = score + earned;
      setScore(newScore);
    }
  };

  /* ---------------- MEMORY MATRIX MODE ---------------- */
  const startMemoryRound = (lvl: number = 1) => {
    setMatrixLevel(lvl);
    setPlayerInput([]);
    setIsShowingPattern(true);

    const length = 2 + lvl;
    const newPat: number[] = [];
    for (let i = 0; i < length; i++) {
      newPat.push(Math.floor(Math.random() * 9));
    }
    setMatrixPattern(newPat);

    // Playback sequence
    newPat.forEach((tileIdx, i) => {
      setTimeout(() => {
        setActiveTile(tileIdx);
        sound.playPop();
        setTimeout(() => setActiveTile(null), 300);
      }, (i + 1) * 600);
    });

    setTimeout(() => {
      setIsShowingPattern(false);
    }, (newPat.length + 1) * 600);
  };

  const handleTileClick = (idx: number) => {
    if (isShowingPattern) return;
    sound.playClick();
    const nextInput = [...playerInput, idx];
    setPlayerInput(nextInput);

    const curStep = nextInput.length - 1;
    if (nextInput[curStep] !== matrixPattern[curStep]) {
      // Wrong!
      sound.playWrong();
      finishGame(score);
      return;
    }

    if (nextInput.length === matrixPattern.length) {
      // Completed round!
      sound.playCorrect();
      const newScore = score + matrixLevel * 25;
      setScore(newScore);
      setTimeout(() => {
        startMemoryRound(matrixLevel + 1);
      }, 700);
    }
  };

  /* ---------------- MATH BLITZ MODE ---------------- */
  const generateMathQuestion = () => {
    const ops = ['+', '-', '*'];
    const op = ops[Math.floor(Math.random() * ops.length)];
    let a = Math.floor(Math.random() * 15) + 2;
    let b = Math.floor(Math.random() * 12) + 2;
    let ans = a + b;

    if (op === '-') {
      if (a < b) [a, b] = [b, a];
      ans = a - b;
    } else if (op === '*') {
      a = Math.floor(Math.random() * 9) + 2;
      b = Math.floor(Math.random() * 9) + 2;
      ans = a * b;
    }

    const opts = new Set<number>();
    opts.add(ans);
    while (opts.size < 4) {
      opts.add(ans + (Math.floor(Math.random() * 9) - 4) || (ans + 1));
    }

    setMathQuestion({
      text: `${a} ${op} ${b} = ?`,
      answer: ans,
      options: Array.from(opts).sort(() => Math.random() - 0.5)
    });
  };

  const handleMathAnswer = (chosen: number) => {
    if (chosen === mathQuestion.answer) {
      sound.playCorrect();
      setScore(prev => prev + 15);
      generateMathQuestion();
    } else {
      sound.playWrong();
      setMathTimer(prev => Math.max(0, prev - 3));
      generateMathQuestion();
    }
  };

  useEffect(() => {
    if (mode === 'math' && !isGameOver) {
      generateMathQuestion();
      const interval = setInterval(() => {
        setMathTimer(prev => {
          if (prev <= 1) {
            clearInterval(interval);
            finishGame(score);
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
      return () => clearInterval(interval);
    }
  }, [mode, isGameOver, finishGame, score]);

  /* ---------------- QUIZ MODE ---------------- */
  const handleQuizAnswer = (chosenIdx: number) => {
    const curQ = QUIZ_QUESTIONS[quizIdx];
    if (chosenIdx === curQ.correct) {
      sound.playCorrect();
      setScore(prev => prev + 25);
    } else {
      sound.playWrong();
    }

    if (quizIdx + 1 < QUIZ_QUESTIONS.length) {
      setQuizIdx(prev => prev + 1);
    } else {
      finishGame(score + (chosenIdx === curQ.correct ? 25 : 0));
    }
  };

  const selectMode = (m: BrainMode) => {
    setMode(m);
    setScore(0);
    setIsGameOver(false);

    if (m === 'reflex') {
      startReflexRound();
    } else if (m === 'memory') {
      startMemoryRound(1);
    } else if (m === 'math') {
      setMathTimer(30);
    } else if (m === 'quiz') {
      setQuizIdx(0);
    }
  };

  const toggleSound = () => {
    const s = sound.toggleSfxMute();
    sound.toggleBgmMute();
    setIsMuted(s);
  };

  return (
    <div className="relative w-full max-w-3xl mx-auto flex flex-col items-center">
      {/* Top Game Bar */}
      <div className="w-full flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 backdrop-blur-md shadow-2xl">
        <button
          onClick={mode ? () => setMode(null) : onBackToHub}
          className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition text-xs sm:text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{mode ? 'Rejimlar' : t.backToHub}</span>
        </button>

        {/* Live HUD Dashboard */}
        <div className="flex items-center gap-3 sm:gap-6 text-xs sm:text-sm font-bold">
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 font-pixel">{score}</span>
          </div>

          <div className="px-3 py-1.5 bg-slate-800/80 rounded-xl text-xs text-slate-300">
            <span className="text-cyan-400">{t.highScore}:</span> {highScore}
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Main Play Area */}
      <div className="w-full min-h-[440px] bg-slate-900/90 border-2 border-cyan-500/40 rounded-3xl p-6 flex flex-col items-center justify-center relative shadow-2xl">
        {/* Mode Selector */}
        {!mode && (
          <div className="w-full flex flex-col items-center text-center">
            <div className="text-6xl mb-3 animate-float">🧠⚡🎯</div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-500 mb-2 font-russo">
              {t.game5Title}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-md mb-8">
              {t.game5Desc}
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 w-full max-w-lg">
              <button
                onClick={() => selectMode('reflex')}
                className="p-5 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 hover:border-cyan-500 rounded-2xl flex items-center gap-4 transition hover:scale-105 active:scale-95 group text-left"
              >
                <div className="p-3 bg-cyan-500/10 text-cyan-400 rounded-xl group-hover:bg-cyan-500 group-hover:text-slate-950 transition">
                  <Zap className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-100">{t.brainReflex}</div>
                  <div className="text-xs text-slate-400">Reaksiya tezligini tekshirish</div>
                </div>
              </button>

              <button
                onClick={() => selectMode('memory')}
                className="p-5 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 hover:border-pink-500 rounded-2xl flex items-center gap-4 transition hover:scale-105 active:scale-95 group text-left"
              >
                <div className="p-3 bg-pink-500/10 text-pink-400 rounded-xl group-hover:bg-pink-500 group-hover:text-slate-950 transition">
                  <Brain className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-100">{t.brainMemory}</div>
                  <div className="text-xs text-slate-400">Ketma-ketlikni eslab qoling</div>
                </div>
              </button>

              <button
                onClick={() => selectMode('math')}
                className="p-5 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 hover:border-amber-500 rounded-2xl flex items-center gap-4 transition hover:scale-105 active:scale-95 group text-left"
              >
                <div className="p-3 bg-amber-500/10 text-amber-400 rounded-xl group-hover:bg-amber-500 group-hover:text-slate-950 transition">
                  <Calculator className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-100">{t.brainMath}</div>
                  <div className="text-xs text-slate-400">30 soniyada tezkor hisob</div>
                </div>
              </button>

              <button
                onClick={() => selectMode('quiz')}
                className="p-5 bg-gradient-to-br from-slate-950 to-slate-900 border border-slate-800 hover:border-emerald-500 rounded-2xl flex items-center gap-4 transition hover:scale-105 active:scale-95 group text-left"
              >
                <div className="p-3 bg-emerald-500/10 text-emerald-400 rounded-xl group-hover:bg-emerald-500 group-hover:text-slate-950 transition">
                  <HelpCircle className="w-6 h-6" />
                </div>
                <div>
                  <div className="font-bold text-slate-100">{t.brainQuiz}</div>
                  <div className="text-xs text-slate-400">Milliy va kiber savollar</div>
                </div>
              </button>
            </div>
          </div>
        )}

        {/* 1. Reflex Screen */}
        {mode === 'reflex' && !isGameOver && (
          <div
            onClick={handleReflexTap}
            className={`w-full h-80 rounded-2xl flex flex-col items-center justify-center p-6 cursor-pointer transition-all select-none ${
              reflexState === 'ready'
                ? 'bg-emerald-500 text-slate-950 glow-green'
                : reflexState === 'waiting'
                ? 'bg-rose-950 text-rose-200 border-2 border-rose-500'
                : 'bg-slate-950 text-slate-200 border border-slate-800'
            }`}
          >
            {reflexState === 'waiting' && (
              <div className="text-2xl sm:text-3xl font-black font-russo animate-pulse">
                {t.brainWaitGreen}
              </div>
            )}
            {reflexState === 'ready' && (
              <div className="text-3xl sm:text-4xl font-black font-russo animate-bounce">
                {t.brainTapGreen}
              </div>
            )}
            {reflexState === 'early' && (
              <div className="text-center">
                <div className="text-2xl font-bold text-rose-400 mb-2">{t.brainTooEarly}</div>
                <button
                  onClick={(e) => { e.stopPropagation(); startReflexRound(); }}
                  className="px-6 py-2 bg-rose-500 text-slate-950 font-bold rounded-xl mt-2"
                >
                  Qayta urinish
                </button>
              </div>
            )}
            {reflexState === 'result' && (
              <div className="text-center">
                <div className="text-4xl font-black text-yellow-400 mb-1 font-pixel">{reflexMs} ms</div>
                <div className="text-sm text-slate-300 mb-4">
                  {reflexMs! < 200 ? '⚡ Afsonaviy chaqmoq tezligi!' : reflexMs! < 280 ? '🎯 Juda yaxshi reaksiya!' : '👍 Yaxshi natija!'}
                </div>
                <button
                  onClick={(e) => { e.stopPropagation(); startReflexRound(); }}
                  className="px-6 py-2.5 bg-cyan-500 text-slate-950 font-bold rounded-xl"
                >
                  Yana bir bor
                </button>
              </div>
            )}
          </div>
        )}

        {/* 2. Memory Matrix Screen */}
        {mode === 'memory' && !isGameOver && (
          <div className="flex flex-col items-center">
            <div className="text-sm font-bold text-pink-400 mb-4 font-mono">
              Daraja: {matrixLevel} ({matrixPattern.length} ta naqsh)
            </div>
            <div className="grid grid-cols-3 gap-3 w-72 h-72">
              {Array.from({ length: 9 }).map((_, idx) => (
                <button
                  key={idx}
                  onClick={() => handleTileClick(idx)}
                  className={`rounded-2xl border-2 transition-all duration-150 ${
                    activeTile === idx
                      ? 'bg-pink-500 border-white shadow-xl scale-105'
                      : 'bg-slate-950 border-slate-800 hover:border-pink-500/50'
                  }`}
                />
              ))}
            </div>
          </div>
        )}

        {/* 3. Math Blitz Screen */}
        {mode === 'math' && !isGameOver && (
          <div className="flex flex-col items-center w-full max-w-md">
            <div className="w-full flex items-center justify-between mb-4">
              <span className="text-amber-400 font-bold text-sm">Vaqt: {mathTimer}s</span>
              <span className="text-slate-400 font-bold text-sm">Ball: {score}</span>
            </div>

            <div className="text-4xl font-black text-slate-100 my-6 font-mono p-4 bg-slate-950 border border-slate-800 rounded-2xl w-full text-center">
              {mathQuestion.text}
            </div>

            <div className="grid grid-cols-2 gap-3 w-full">
              {mathQuestion.options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => handleMathAnswer(opt)}
                  className="p-4 bg-slate-950 hover:bg-amber-950 border border-slate-800 hover:border-amber-400 text-slate-100 font-bold text-xl rounded-2xl transition active:scale-95"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* 4. Quiz Screen */}
        {mode === 'quiz' && !isGameOver && (
          <div className="flex flex-col items-center w-full max-w-lg">
            <div className="text-xs text-slate-400 mb-2 font-mono">
              Savol {quizIdx + 1} / {QUIZ_QUESTIONS.length}
            </div>

            <div className="text-base sm:text-lg font-bold text-slate-100 my-4 p-4 bg-slate-950 border border-slate-800 rounded-2xl w-full text-center leading-relaxed">
              {QUIZ_QUESTIONS[quizIdx].q}
            </div>

            <div className="flex flex-col gap-2.5 w-full mt-2">
              {QUIZ_QUESTIONS[quizIdx].options.map((opt, i) => (
                <button
                  key={i}
                  onClick={() => handleQuizAnswer(i)}
                  className="p-3.5 bg-slate-950 hover:bg-emerald-950 border border-slate-800 hover:border-emerald-400 text-slate-200 font-semibold text-sm rounded-xl transition text-left active:scale-98"
                >
                  {opt}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Game Over Screen */}
        {isGameOver && (
          <div className="flex flex-col items-center text-center">
            <h2 className="text-3xl font-black text-yellow-400 mb-2 font-russo">
              {t.gameOver}
            </h2>
            <div className="text-lg text-slate-300 mb-6 font-cyber">
              To'plangan Ball: <span className="text-yellow-400 font-bold">{score}</span>
            </div>

            <div className="flex gap-4">
              <button
                onClick={() => selectMode(mode!)}
                className="px-6 py-2.5 bg-cyan-500 text-slate-950 font-bold rounded-xl flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.restart}</span>
              </button>
              <button
                onClick={() => setMode(null)}
                className="px-6 py-2.5 bg-slate-800 text-slate-200 font-bold rounded-xl"
              >
                Rejimlar
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
