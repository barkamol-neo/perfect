import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { 
  Play, RotateCcw, Volume2, VolumeX, Trophy, ArrowLeft,
  Shuffle
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface MergeGameProps {
  profile: PlayerProfile;
  language: Language;
  onUpdateProfile: (profile: PlayerProfile) => void;
  onBackToHub: () => void;
}

export interface FruitTier {
  tier: number;
  name: string;
  emoji: string;
  radius: number;
  color: string;
  points: number;
}

export const FRUIT_TIERS: FruitTier[] = [
  { tier: 0, name: "Qalampir", emoji: "🌶️", radius: 18, color: "#ef4444", points: 2 },
  { tier: 1, name: "O'rik", emoji: "🍑", radius: 24, color: "#f97316", points: 4 },
  { tier: 2, name: "Anjir", emoji: "🫐", radius: 30, color: "#8b5cf6", points: 8 },
  { tier: 3, name: "Shaftoli", emoji: "🍑", radius: 38, color: "#fb7185", points: 16 },
  { tier: 4, name: "Qizil Olma", emoji: "🍎", radius: 46, color: "#dc2626", points: 32 },
  { tier: 5, name: "Shirin Anor", emoji: "🍅", radius: 56, color: "#b91c1c", points: 64 },
  { tier: 6, name: "Mirzacho'l Qovuni", emoji: "🍈", radius: 68, color: "#ca8a04", points: 128 },
  { tier: 7, name: "Qandak Tarvuz", emoji: "🍉", radius: 82, color: "#16a34a", points: 256 },
  { tier: 8, name: "Tandir Somsa", emoji: "🥟", radius: 96, color: "#d97706", points: 512 },
  { tier: 9, name: "Shohona Palov", emoji: "🍲", radius: 110, color: "#b45309", points: 1024 },
  { tier: 10, name: "Oltin Humo Toji", emoji: "👑", radius: 125, color: "#eab308", points: 2048 },
];

interface Body {
  id: number;
  tier: number;
  x: number;
  y: number;
  vx: number;
  vy: number;
  radius: number;
  scale: number;
  isMerging?: boolean;
}

interface MergeParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
}

export const MergeGame: React.FC<MergeGameProps> = ({
  language,
  onUpdateProfile,
  onBackToHub
}) => {
  const t = getTranslation(language);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const [gameState, setGameState] = useState<'menu' | 'playing' | 'gameover'>('menu');
  const [score, setScore] = useState(0);
  const [coinsEarned, setCoinsEarned] = useState(0);
  const [highScore, setHighScore] = useState(0);
  const [nextTier, setNextTier] = useState(0);
  const [shakeCooldown, setShakeCooldown] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  const engineRef = useRef({
    bodies: [] as Body[],
    particles: [] as MergeParticle[],
    currentTier: 0,
    nextTier: 0,
    aimX: 240,
    score: 0,
    canDrop: true,
    dropCooldown: 0,
    dangerTimer: 0,
    shakeX: 0,
    shakeY: 0,
    maxTierAchieved: 0
  });

  useEffect(() => {
    const stats = storage.getStats();
    setHighScore(stats.mergeHighScore);
    sound.startBgm('chill_lounge');

    return () => {
      sound.stopBgm();
    };
  }, []);

  const getRandomSpawnTier = () => {
    // Only spawn tiers 0 to 3
    return Math.floor(Math.random() * 4);
  };

  const startGame = () => {
    const eng = engineRef.current;
    eng.bodies = [];
    eng.particles = [];
    eng.currentTier = getRandomSpawnTier();
    eng.nextTier = getRandomSpawnTier();
    eng.aimX = 240;
    eng.score = 0;
    eng.canDrop = true;
    eng.dropCooldown = 0;
    eng.dangerTimer = 0;
    eng.maxTierAchieved = 0;

    setScore(0);
    setCoinsEarned(0);
    setNextTier(eng.nextTier);
    setShakeCooldown(0);
    setGameState('playing');
    sound.startBgm('chill_lounge');
  };

  const handleGameOver = useCallback(() => {
    const eng = engineRef.current;
    setGameState('gameover');
    sound.playGameOver();

    const finalScore = eng.score;
    const finalCoins = Math.floor(finalScore / 25);

    const stats = storage.getStats();
    if (finalScore > stats.mergeHighScore) {
      stats.mergeHighScore = finalScore;
      setHighScore(finalScore);
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    }
    stats.mergeMaxFruitLevel = Math.max(stats.mergeMaxFruitLevel, eng.maxTierAchieved);
    stats.totalGamesPlayed += 1;
    storage.saveStats(stats);

    const updated = storage.addCoinsAndDiamonds(finalCoins, eng.maxTierAchieved >= 7 ? 2 : 0);

    // Quests check
    const quests = storage.getDailyQuests();
    quests.forEach(q => {
      if (q.targetGame === 'merge' || q.targetGame === 'any') {
        if (q.id === 'quest_merge_500') {
          q.progress += finalScore;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
        if (q.id === 'quest_play_games') {
          q.progress += 1;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
      }
    });
    storage.saveDailyQuests(quests);

    // Achievements check
    const achs = storage.getAchievements();
    achs.forEach(a => {
      if (a.id === 'merge_watermelon' && eng.maxTierAchieved >= 7) {
        a.progress = 1;
        a.isUnlocked = true;
      }
    });
    storage.saveAchievements(achs);

    setCoinsEarned(finalCoins);
    onUpdateProfile(updated);
  }, [onUpdateProfile]);

  const triggerDrop = () => {
    const eng = engineRef.current;
    if (!eng.canDrop || gameState !== 'playing') return;

    const tObj = FRUIT_TIERS[eng.currentTier];
    eng.bodies.push({
      id: Math.random(),
      tier: eng.currentTier,
      x: eng.aimX,
      y: 90,
      vx: (Math.random() - 0.5) * 0.5,
      vy: 2.5,
      radius: tObj.radius,
      scale: 1.0
    });

    sound.playPop();
    eng.canDrop = false;
    eng.dropCooldown = 35; // cooldown
    eng.currentTier = eng.nextTier;
    eng.nextTier = getRandomSpawnTier();
    setNextTier(eng.nextTier);
  };

  const triggerShake = () => {
    const eng = engineRef.current;
    if (shakeCooldown > 0 || gameState !== 'playing') return;
    setShakeCooldown(120); // 2 seconds
    sound.playDash();

    // Give random upward & sideways impulse to all items
    eng.bodies.forEach(b => {
      b.vy -= Math.random() * 5 + 3;
      b.vx += (Math.random() - 0.5) * 6;
    });
  };

  // Canvas Mouse & Touch Aiming Handlers
  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const clientX = (e.clientX - rect.left) * scaleX;

    const curR = FRUIT_TIERS[engineRef.current.currentTier]?.radius || 20;
    const minX = 40 + curR;
    const maxX = canvas.width - 40 - curR;

    engineRef.current.aimX = Math.max(minX, Math.min(maxX, clientX));
  };

  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    handlePointerMove(e);
    triggerDrop();
  };

  // Physics Simulation & Render Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const wallLeft = 35;
    const wallRight = canvas.width - 35;
    const floorY = canvas.height - 35;
    const dangerLineY = 120;

    const loop = () => {
      if (gameState === 'playing') {
        const eng = engineRef.current;

        // Drop cooldown
        if (eng.dropCooldown > 0) {
          eng.dropCooldown--;
          if (eng.dropCooldown === 0) eng.canDrop = true;
        }

        // Apply Gravity & Velocity to Bodies
        const gravity = 0.32;
        const restitution = 0.25; // bounce factor
        const friction = 0.985; // air/roll friction

        for (let i = 0; i < eng.bodies.length; i++) {
          const b = eng.bodies[i];
          b.vy += gravity;
          b.vx *= friction;
          b.vy *= friction;

          b.x += b.vx;
          b.y += b.vy;

          // Wall Collisions
          if (b.x - b.radius < wallLeft) {
            b.x = wallLeft + b.radius;
            b.vx = -b.vx * restitution;
          } else if (b.x + b.radius > wallRight) {
            b.x = wallRight - b.radius;
            b.vx = -b.vx * restitution;
          }

          // Floor Collision
          if (b.y + b.radius > floorY) {
            b.y = floorY - b.radius;
            b.vy = -b.vy * restitution;
            if (Math.abs(b.vy) < 0.2) b.vy = 0;
          }
        }

        // Body-to-Body Collision & Merge Resolution (Iterate multi-pass for stability)
        for (let pass = 0; pass < 6; pass++) {
          for (let i = 0; i < eng.bodies.length; i++) {
            for (let j = i + 1; j < eng.bodies.length; j++) {
              const b1 = eng.bodies[i];
              const b2 = eng.bodies[j];
              if (!b1 || !b2) continue;

              const dx = b2.x - b1.x;
              const dy = b2.y - b1.y;
              const dist = Math.sqrt(dx * dx + dy * dy);
              const minDist = b1.radius + b2.radius;

              if (dist < minDist && dist > 0) {
                // Check if same tier -> MERGE!
                if (b1.tier === b2.tier && !b1.isMerging && !b2.isMerging && b1.tier < FRUIT_TIERS.length - 1) {
                  b1.isMerging = true;
                  b2.isMerging = true;

                  const nextT = b1.tier + 1;
                  const newX = (b1.x + b2.x) / 2;
                  const newY = (b1.y + b2.y) / 2;
                  const newR = FRUIT_TIERS[nextT].radius;

                  sound.playMerge();
                  eng.score += FRUIT_TIERS[nextT].points;
                  eng.maxTierAchieved = Math.max(eng.maxTierAchieved, nextT);

                  // Merge Particles
                  for (let k = 0; k < 15; k++) {
                    eng.particles.push({
                      x: newX,
                      y: newY,
                      vx: (Math.random() - 0.5) * 7,
                      vy: (Math.random() - 0.5) * 7,
                      color: FRUIT_TIERS[nextT].color,
                      size: Math.random() * 5 + 3,
                      life: 22
                    });
                  }

                  // Delete b2, upgrade b1
                  eng.bodies.splice(j, 1);
                  b1.tier = nextT;
                  b1.x = newX;
                  b1.y = newY;
                  b1.radius = newR;
                  b1.vx *= 0.3;
                  b1.vy = -1.5; // gentle upward pop
                  b1.isMerging = false;

                  if (nextT >= 7) {
                    confetti({ particleCount: 30, spread: 50, origin: { x: newX / canvas.width, y: newY / canvas.height } });
                  }
                  break;
                } else {
                  // Standard Elastic Circle Collision
                  const overlap = minDist - dist;
                  const nx = dx / dist;
                  const ny = dy / dist;

                  // Separate circles
                  b1.x -= nx * overlap * 0.5;
                  b1.y -= ny * overlap * 0.5;
                  b2.x += nx * overlap * 0.5;
                  b2.y += ny * overlap * 0.5;

                  // Relative velocity
                  const kx = b1.vx - b2.vx;
                  const ky = b1.vy - b2.vy;
                  const p = 2 * (nx * kx + ny * ky) / 2;

                  b1.vx -= p * nx * restitution;
                  b1.vy -= p * ny * restitution;
                  b2.vx += p * nx * restitution;
                  b2.vy += p * ny * restitution;
                }
              }
            }
          }
        }

        // Danger Line Overflow Check
        let isOverflowing = false;
        for (let i = 0; i < eng.bodies.length; i++) {
          const b = eng.bodies[i];
          if (b.y - b.radius < dangerLineY && Math.abs(b.vy) < 0.5) {
            isOverflowing = true;
            break;
          }
        }

        if (isOverflowing) {
          eng.dangerTimer++;
          if (eng.dangerTimer >= 180) { // 3 seconds over limit
            handleGameOver();
          }
        } else {
          eng.dangerTimer = Math.max(0, eng.dangerTimer - 1);
        }

        // Update Particles
        for (let i = eng.particles.length - 1; i >= 0; i--) {
          const p = eng.particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.life--;
          if (p.life <= 0) eng.particles.splice(i, 1);
        }

        // Sync React HUD
        setScore(eng.score);
        if (shakeCooldown > 0) setShakeCooldown(prev => prev - 1);
      }

      /* ---------------- RENDERING CANVAS ---------------- */
      ctx.save();

      // Background Jar Container
      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Glass Container Fill & Border
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(wallLeft, 70, wallRight - wallLeft, floorY - 70);

      ctx.strokeStyle = '#06b6d4';
      ctx.lineWidth = 6;
      ctx.strokeRect(wallLeft, 70, wallRight - wallLeft, floorY - 70);

      // Danger Top Line
      const isRedWarning = engineRef.current.dangerTimer > 60;
      ctx.strokeStyle = isRedWarning ? '#ef4444' : 'rgba(239, 68, 68, 0.4)';
      ctx.lineWidth = 2;
      ctx.setLineDash([8, 6]);
      ctx.beginPath();
      ctx.moveTo(wallLeft, dangerLineY);
      ctx.lineTo(wallRight, dangerLineY);
      ctx.stroke();
      ctx.setLineDash([]);

      // Draw Aiming Guide & Current Drop Fruit
      if (gameState === 'playing' && engineRef.current.canDrop) {
        const eng = engineRef.current;
        const curFruit = FRUIT_TIERS[eng.currentTier];

        // Vertical drop laser line
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.35)';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(eng.aimX, 90);
        ctx.lineTo(eng.aimX, floorY);
        ctx.stroke();

        // Aiming Fruit
        ctx.save();
        ctx.translate(eng.aimX, 85);
        ctx.font = `${curFruit.radius * 1.5}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(curFruit.emoji, 0, 0);
        ctx.restore();
      }

      // Draw Bodies (Fruits / Somsas)
      engineRef.current.bodies.forEach(b => {
        const tObj = FRUIT_TIERS[b.tier];
        ctx.save();
        ctx.translate(b.x, b.y);

        // Circular background glow
        ctx.fillStyle = tObj.color;
        ctx.beginPath();
        ctx.arc(0, 0, b.radius, 0, Math.PI * 2);
        ctx.fill();

        ctx.strokeStyle = 'rgba(255, 255, 255, 0.3)';
        ctx.lineWidth = 2;
        ctx.stroke();

        // Emoji Icon
        ctx.font = `${b.radius * 1.25}px sans-serif`;
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(tObj.emoji, 0, 0);

        ctx.restore();
      });

      // Draw Particles
      engineRef.current.particles.forEach(p => {
        ctx.save();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / 22;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [gameState, handleGameOver, shakeCooldown]);

  const toggleSound = () => {
    const s = sound.toggleSfxMute();
    sound.toggleBgmMute();
    setIsMuted(s);
  };

  return (
    <div className="relative w-full max-w-4xl mx-auto flex flex-col items-center">
      {/* Top Game Bar */}
      <div className="w-full flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 backdrop-blur-md shadow-2xl">
        <button
          onClick={onBackToHub}
          className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition text-xs sm:text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.backToHub}</span>
        </button>

        {/* Live HUD Dashboard */}
        <div className="flex items-center gap-3 sm:gap-6 text-xs sm:text-sm font-bold">
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 font-pixel">{score}</span>
          </div>

          <div className="flex items-center gap-2 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-slate-400 text-xs">{t.mergeNext}:</span>
            <span className="text-lg">{FRUIT_TIERS[nextTier]?.emoji}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Canvas Area Container */}
      <div className="relative w-full max-w-[480px] aspect-[4/5] bg-slate-950 rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-2xl">
        <canvas
          ref={canvasRef}
          width={480}
          height={600}
          onPointerMove={handlePointerMove}
          onPointerDown={handlePointerDown}
          className="w-full h-full object-contain block cursor-crosshair touch-none"
        />

        {/* Shake Button Floating */}
        {gameState === 'playing' && (
          <button
            onClick={triggerShake}
            disabled={shakeCooldown > 0}
            className={`absolute bottom-4 right-4 px-4 py-2.5 rounded-xl font-bold text-xs sm:text-sm flex items-center gap-2 shadow-xl backdrop-blur-md transition ${
              shakeCooldown > 0
                ? 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 active:scale-95'
            }`}
          >
            <Shuffle className="w-4 h-4" />
            <span>{t.mergeShake}</span>
          </button>
        )}

        {/* Overlay: Menu / Start */}
        {gameState === 'menu' && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="text-6xl mb-3 animate-float">🍉🥟🍲</div>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 via-yellow-400 to-amber-500 mb-2 font-russo tracking-wide">
              {t.game3Title}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-xs mb-6 leading-relaxed">
              {t.game3Desc}
            </p>

            <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300 mb-6">
              <span className="text-yellow-400 font-bold">{t.highScore}:</span> {highScore}
            </div>

            <button
              onClick={startGame}
              className="px-8 py-3.5 bg-gradient-to-r from-emerald-500 via-green-500 to-emerald-600 hover:from-emerald-400 hover:to-green-500 text-slate-950 font-black text-base sm:text-lg rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition flex items-center gap-3 glow-green"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>{t.playNow}</span>
            </button>
          </div>
        )}

        {/* Overlay: Game Over */}
        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <h2 className="text-3xl font-black text-rose-500 mb-2 font-russo">
              {t.gameOver}
            </h2>
            <p className="text-slate-400 text-sm mb-6 font-cyber">
              Ajoyib shirinliklar hosil qildingiz!
            </p>

            <div className="grid grid-cols-2 gap-3 max-w-xs w-full mb-6">
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.score}</div>
                <div className="text-lg font-bold text-yellow-400 font-pixel">{score}</div>
              </div>
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.coins}</div>
                <div className="text-lg font-bold text-amber-400">+{coinsEarned} 🪙</div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={startGame}
                className="px-6 py-2.5 bg-gradient-to-r from-emerald-500 to-green-600 text-slate-950 font-bold rounded-xl shadow-lg hover:scale-105 transition flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.restart}</span>
              </button>
              <button
                onClick={onBackToHub}
                className="px-6 py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition"
              >
                {t.backToHub}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Evolution Tree Preview */}
      <div className="w-full mt-4 p-3 bg-slate-900/80 border border-slate-800 rounded-2xl flex items-center justify-between overflow-x-auto gap-2">
        {FRUIT_TIERS.map((tier) => (
          <div key={tier.tier} className="flex flex-col items-center min-w-[42px] p-1.5 bg-slate-950/60 rounded-xl border border-slate-800">
            <span className="text-lg sm:text-xl">{tier.emoji}</span>
            <span className="text-[10px] text-slate-400 font-bold mt-1">{tier.points}p</span>
          </div>
        ))}
      </div>

      {/* Guide */}
      <div className="w-full mt-3 p-3 bg-slate-900/50 border border-slate-800/80 rounded-xl text-center text-xs text-slate-400">
        <span className="text-slate-300 font-bold">{t.controls}: </span>
        {t.mergeControls}
      </div>
    </div>
  );
};
