import React, { useEffect, useRef, useState, useCallback } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage, CARS_CATALOG } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { 
  Play, RotateCcw, Volume2, VolumeX, Trophy, ArrowLeft,
  Gauge, Shield, Flame
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface RacerGameProps {
  profile: PlayerProfile;
  language: Language;
  onUpdateProfile: (profile: PlayerProfile) => void;
  onBackToHub: () => void;
}

interface TrafficCar {
  id: number;
  x: number;
  y: number;
  width: number;
  height: number;
  speed: number;
  emoji: string;
  color: string;
  isPolice?: boolean;
}

interface RoadItem {
  id: number;
  x: number;
  y: number;
  type: 'coin' | 'diamond' | 'fuel' | 'nitro' | 'wrench';
  radius: number;
}

interface RoadParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  color: string;
  size: number;
  life: number;
}

export const RacerGame: React.FC<RacerGameProps> = ({
  profile,
  language,
  onUpdateProfile,
  onBackToHub
}) => {
  const t = getTranslation(language);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const car = CARS_CATALOG.find(c => c.id === profile.selectedCarId) || CARS_CATALOG[0];

  const [gameState, setGameState] = useState<'menu' | 'playing' | 'paused' | 'gameover'>('menu');
  const [score, setScore] = useState(0);
  const [coinsCollected, setCoinsCollected] = useState(0);
  const [diamondsCollected, setDiamondsCollected] = useState(0);
  const [speedKmh, setSpeedKmh] = useState(0);
  const [distanceM, setDistanceM] = useState(0);
  const [nitroAmount, setNitroAmount] = useState(100);
  const [carHp, setCarHp] = useState(100);
  const [highScore, setHighScore] = useState(0);
  const [isMuted, setIsMuted] = useState(false);

  const engineRef = useRef({
    carX: 480, // center lane
    carY: 420,
    carVx: 0,
    speed: 0,
    targetSpeed: 120,
    maxSpeed: car.stats.topSpeed,
    nitro: 100,
    isNitroActive: false,
    hp: 100,
    score: 0,
    coins: 0,
    diamonds: 0,
    distance: 0,
    roadOffset: 0,
    shake: 0,
    traffic: [] as TrafficCar[],
    roadItems: [] as RoadItem[],
    particles: [] as RoadParticle[],
    nextTrafficDist: 100,
    nextItemDist: 150,
    nitroUsedCount: 0,
    keys: {
      left: false,
      right: false,
      up: false,
      down: false,
      nitro: false
    }
  });

  useEffect(() => {
    const stats = storage.getStats();
    setHighScore(stats.racerHighScore);
    sound.startBgm('neon_highway');

    return () => {
      sound.stopBgm();
    };
  }, []);

  // Controls Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') engineRef.current.keys.left = true;
      if (k === 'arrowright' || k === 'd') engineRef.current.keys.right = true;
      if (k === 'arrowup' || k === 'w') engineRef.current.keys.up = true;
      if (k === 'arrowdown' || k === 's') engineRef.current.keys.down = true;
      if (k === ' ' || k === 'shift') {
        e.preventDefault();
        engineRef.current.keys.nitro = true;
      }
      if (k === 'p' || k === 'escape') {
        setGameState(prev => prev === 'playing' ? 'paused' : prev === 'paused' ? 'playing' : prev);
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      const k = e.key.toLowerCase();
      if (k === 'arrowleft' || k === 'a') engineRef.current.keys.left = false;
      if (k === 'arrowright' || k === 'd') engineRef.current.keys.right = false;
      if (k === 'arrowup' || k === 'w') engineRef.current.keys.up = false;
      if (k === 'arrowdown' || k === 's') engineRef.current.keys.down = false;
      if (k === ' ' || k === 'shift') engineRef.current.keys.nitro = false;
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, []);

  const startGame = () => {
    const eng = engineRef.current;
    eng.carX = 480;
    eng.carY = 420;
    eng.carVx = 0;
    eng.speed = 80;
    eng.targetSpeed = 140;
    eng.maxSpeed = car.stats.topSpeed;
    eng.nitro = 100;
    eng.isNitroActive = false;
    eng.hp = 100;
    eng.score = 0;
    eng.coins = 0;
    eng.diamonds = 0;
    eng.distance = 0;
    eng.traffic = [];
    eng.roadItems = [];
    eng.particles = [];
    eng.nextTrafficDist = 100;
    eng.nextItemDist = 150;
    eng.nitroUsedCount = 0;

    setScore(0);
    setCoinsCollected(0);
    setDiamondsCollected(0);
    setSpeedKmh(80);
    setDistanceM(0);
    setNitroAmount(100);
    setCarHp(100);
    setGameState('playing');
    sound.startBgm('neon_highway');
  };

  const handleGameOver = useCallback(() => {
    const eng = engineRef.current;
    setGameState('gameover');
    sound.playExplosion();

    const finalScore = eng.score;
    const finalCoins = eng.coins;
    const finalDiamonds = eng.diamonds;

    const stats = storage.getStats();
    if (finalScore > stats.racerHighScore) {
      stats.racerHighScore = finalScore;
      setHighScore(finalScore);
      confetti({ particleCount: 70, spread: 80, origin: { y: 0.6 } });
    }
    stats.racerMaxSpeed = Math.max(stats.racerMaxSpeed, Math.floor(eng.speed));
    stats.totalGamesPlayed += 1;
    storage.saveStats(stats);

    const updated = storage.addCoinsAndDiamonds(finalCoins, finalDiamonds);

    // Quests check
    const quests = storage.getDailyQuests();
    quests.forEach(q => {
      if (q.targetGame === 'racer' || q.targetGame === 'any') {
        if (q.id === 'quest_racer_nitro') {
          q.progress += eng.nitroUsedCount;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
        if (q.id === 'quest_play_games') {
          q.progress += 1;
          if (q.progress >= q.targetAmount) q.isCompleted = true;
        }
      }
    });
    storage.saveDailyQuests(quests);

    // Achievements check
    const achs = storage.getAchievements();
    achs.forEach(a => {
      if (a.id === 'speed_demon_250' && eng.speed >= 250) {
        a.progress = Math.min(a.maxProgress, Math.floor(eng.speed));
        if (a.progress >= a.maxProgress) a.isUnlocked = true;
      }
    });
    storage.saveAchievements(achs);

    onUpdateProfile(updated);
  }, [onUpdateProfile]);

  // Main Canvas Loop
  useEffect(() => {
    let animId: number;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const roadLeft = 240;
    const roadRight = 720;
    const roadWidth = roadRight - roadLeft;

    const loop = () => {
      if (gameState === 'playing') {
        const eng = engineRef.current;

        // Nitro Logic
        if (eng.keys.nitro && eng.nitro > 0) {
          eng.isNitroActive = true;
          eng.nitro = Math.max(0, eng.nitro - 0.7);
          eng.targetSpeed = eng.maxSpeed * 1.35;
          eng.score += 4;
          if (Math.random() < 0.1) {
            eng.nitroUsedCount++;
            sound.playTurbo();
          }
        } else {
          eng.isNitroActive = false;
          if (eng.keys.up) eng.targetSpeed = eng.maxSpeed;
          else if (eng.keys.down) eng.targetSpeed = 60;
          else eng.targetSpeed = eng.maxSpeed * 0.75;

          // Slow natural nitro recharge
          if (eng.nitro < 100) eng.nitro = Math.min(100, eng.nitro + 0.15);
        }

        // Speed Interpolation
        const accelRate = (car.stats.acceleration / 100) * 0.8;
        eng.speed += (eng.targetSpeed - eng.speed) * accelRate * 0.1;

        // Distance & Score
        const frameDist = eng.speed / 80;
        eng.distance += frameDist;
        eng.score += Math.floor(eng.speed / 40);

        // Steering Physics with Handling
        const handleSpeed = (car.stats.handling / 100) * 6.5;
        if (eng.keys.left) eng.carVx = -handleSpeed;
        else if (eng.keys.right) eng.carVx = handleSpeed;
        else eng.carVx *= 0.8; // friction

        eng.carX += eng.carVx;

        // Screen Shake decay
        if (eng.shake > 0) eng.shake--;

        // Road Boundaries check
        if (eng.carX < roadLeft + 30) {
          eng.carX = roadLeft + 30;
          eng.speed *= 0.95; // grass slowdown
          eng.shake = 3;
        } else if (eng.carX > roadRight - 30) {
          eng.carX = roadRight - 30;
          eng.speed *= 0.95;
          eng.shake = 3;
        }

        // Spawn Traffic Cars
        if (eng.distance >= eng.nextTrafficDist) {
          eng.nextTrafficDist = eng.distance + Math.random() * 80 + 50;
          const lanes = [roadLeft + 60, roadLeft + 180, roadLeft + 300, roadLeft + 420];
          const spawnLaneX = lanes[Math.floor(Math.random() * lanes.length)];
          const isPolice = Math.random() < 0.15;

          const trafficEmojis = ['🚕', '🚗', '🚙', '🚚', '🏎️'];
          const emoji = isPolice ? '🚓' : trafficEmojis[Math.floor(Math.random() * trafficEmojis.length)];

          eng.traffic.push({
            id: Math.random(),
            x: spawnLaneX,
            y: -100,
            width: 48,
            height: 75,
            speed: isPolice ? eng.maxSpeed * 0.6 : (Math.random() * 40 + 50),
            emoji,
            color: isPolice ? '#1e3a8a' : '#475569',
            isPolice
          });
        }

        // Spawn Road Items
        if (eng.distance >= eng.nextItemDist) {
          eng.nextItemDist = eng.distance + Math.random() * 60 + 40;
          const rx = roadLeft + 40 + Math.random() * (roadWidth - 80);
          const rTypeRand = Math.random();
          let rType: RoadItem['type'] = 'coin';
          if (rTypeRand < 0.1) rType = 'diamond';
          else if (rTypeRand < 0.25) rType = 'fuel';
          else if (rTypeRand < 0.4) rType = 'nitro';
          else if (rTypeRand < 0.5) rType = 'wrench';

          eng.roadItems.push({
            id: Math.random(),
            x: rx,
            y: -50,
            type: rType,
            radius: 14
          });
        }

        // Update Traffic Cars
        for (let i = eng.traffic.length - 1; i >= 0; i--) {
          const tc = eng.traffic[i];
          // Relative speed motion
          const relSpeed = (eng.speed - tc.speed) / 10;
          tc.y += relSpeed;

          // Collision with Player Car
          const hit = (
            eng.carX + 22 > tc.x - tc.width / 2 &&
            eng.carX - 22 < tc.x + tc.width / 2 &&
            eng.carY + 35 > tc.y - tc.height / 2 &&
            eng.carY - 35 < tc.y + tc.height / 2
          );

          if (hit) {
            if (eng.isNitroActive) {
              // Nitro ramming pushes traffic away
              sound.playHit();
              tc.y += 120;
              eng.score += 250;
              eng.coins += 5;
            } else {
              // Heavy crash
              sound.playHit();
              eng.hp -= 25;
              eng.speed *= 0.6;
              eng.shake = 15;
              tc.y += 80;

              if (eng.hp <= 0) {
                handleGameOver();
                break;
              }
            }
          }

          // Offscreen bottom or far top
          if (tc.y > canvas.height + 150 || tc.y < -300) {
            eng.traffic.splice(i, 1);
          }
        }

        // Update Road Items
        for (let i = eng.roadItems.length - 1; i >= 0; i--) {
          const item = eng.roadItems[i];
          item.y += eng.speed / 10;

          // Collect
          const dist = Math.hypot(eng.carX - item.x, eng.carY - item.y);
          if (dist < 36) {
            if (item.type === 'coin') {
              sound.playCoin();
              eng.coins += 1;
              eng.score += 50;
            } else if (item.type === 'diamond') {
              sound.playDiamond();
              eng.diamonds += 1;
              eng.score += 300;
            } else if (item.type === 'nitro') {
              sound.playPowerup();
              eng.nitro = Math.min(100, eng.nitro + 40);
            } else if (item.type === 'wrench') {
              sound.playPowerup();
              eng.hp = Math.min(100, eng.hp + 30);
            }

            eng.roadItems.splice(i, 1);
            continue;
          }

          if (item.y > canvas.height + 50) {
            eng.roadItems.splice(i, 1);
          }
        }

        // Nitro exhaust particles
        if (eng.isNitroActive) {
          for (let k = 0; k < 3; k++) {
            eng.particles.push({
              x: eng.carX + (Math.random() - 0.5) * 20,
              y: eng.carY + 40,
              vx: (Math.random() - 0.5) * 3,
              vy: Math.random() * 8 + 6,
              color: Math.random() < 0.5 ? '#06b6d4' : '#3b82f6',
              size: Math.random() * 6 + 3,
              life: 15
            });
          }
        }

        // Update Particles
        for (let i = eng.particles.length - 1; i >= 0; i--) {
          const p = eng.particles[i];
          p.x += p.vx;
          p.y += p.vy;
          p.life--;
          if (p.life <= 0) eng.particles.splice(i, 1);
        }

        // Sync React HUD
        setScore(eng.score);
        setCoinsCollected(eng.coins);
        setDiamondsCollected(eng.diamonds);
        setSpeedKmh(Math.floor(eng.speed));
        setDistanceM(Math.floor(eng.distance));
        setNitroAmount(Math.floor(eng.nitro));
        setCarHp(Math.max(0, eng.hp));
      }

      /* ---------------- RENDERING CANVAS ---------------- */
      ctx.save();

      const eng = engineRef.current;
      if (eng.shake > 0) {
        ctx.translate((Math.random() - 0.5) * eng.shake * 1.5, (Math.random() - 0.5) * eng.shake * 1.5);
      }

      // Background Scenery (Road Shoulders & Desert/Mountains)
      ctx.fillStyle = '#0f172a'; // Grass / desert
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Distant City Lights on Top
      ctx.fillStyle = '#1e1b4b';
      ctx.fillRect(0, 0, canvas.width, 80);
      ctx.fillStyle = '#fde047';
      for (let x = 20; x < canvas.width; x += 30) {
        if (Math.sin(x) > 0) ctx.fillRect(x, 40, 6, 8);
      }

      // Asphalt Road
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(roadLeft, 0, roadWidth, canvas.height);

      // Road Borders (Glowing Neon Curbs)
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(roadLeft - 8, 0, 8, canvas.height);
      ctx.fillStyle = '#06b6d4';
      ctx.fillRect(roadRight, 0, 8, canvas.height);

      // Moving White Lane Divider Stripes
      eng.roadOffset = (eng.roadOffset + eng.speed / 5) % 60;
      ctx.fillStyle = '#e2e8f0';
      const laneWidth = roadWidth / 4;
      for (let l = 1; l < 4; l++) {
        const lx = roadLeft + l * laneWidth;
        for (let y = -eng.roadOffset; y < canvas.height; y += 60) {
          ctx.fillRect(lx - 3, y, 6, 32);
        }
      }

      // Speed lines when high speed / nitro
      if (eng.speed > 220 || eng.isNitroActive) {
        ctx.strokeStyle = 'rgba(6, 182, 212, 0.35)';
        ctx.lineWidth = 2;
        for (let i = 0; i < 15; i++) {
          const sx = Math.random() * canvas.width;
          const sy = Math.random() * canvas.height;
          ctx.beginPath();
          ctx.moveTo(sx, sy);
          ctx.lineTo(sx, sy + 60);
          ctx.stroke();
        }
      }

      // Draw Road Items
      eng.roadItems.forEach(item => {
        ctx.save();
        ctx.translate(item.x, item.y);
        if (item.type === 'coin') {
          ctx.fillStyle = '#eab308';
          ctx.beginPath();
          ctx.arc(0, 0, item.radius, 0, Math.PI * 2);
          ctx.fill();
          ctx.fillStyle = '#713f12';
          ctx.font = 'bold 11px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('UZ', 0, 0);
        } else if (item.type === 'diamond') {
          ctx.font = '22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('💎', 0, 0);
        } else if (item.type === 'nitro') {
          ctx.font = '22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('⚡', 0, 0);
        } else if (item.type === 'wrench') {
          ctx.font = '22px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('🔧', 0, 0);
        }
        ctx.restore();
      });

      // Draw Traffic Cars
      eng.traffic.forEach(tc => {
        ctx.save();
        ctx.translate(tc.x, tc.y);
        ctx.font = '48px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(tc.emoji, 0, 0);

        // Police flashing siren
        if (tc.isPolice) {
          const isRed = (Date.now() % 400) < 200;
          ctx.fillStyle = isRed ? '#ef4444' : '#3b82f6';
          ctx.beginPath();
          ctx.arc(0, -18, 6, 0, Math.PI * 2);
          ctx.fill();
        }
        ctx.restore();
      });

      // Draw Nitro Exhaust Particles
      eng.particles.forEach(p => {
        ctx.save();
        ctx.fillStyle = p.color;
        ctx.globalAlpha = p.life / 15;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      // Draw Player Car
      ctx.save();
      ctx.translate(eng.carX, eng.carY);

      // Nitro Glow Aura
      if (eng.isNitroActive) {
        ctx.fillStyle = 'rgba(6, 182, 212, 0.4)';
        ctx.beginPath();
        ctx.ellipse(0, 0, 35, 55, 0, 0, Math.PI * 2);
        ctx.fill();
      }

      // Car Body
      ctx.font = '54px sans-serif';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(car.imageOrEmoji, 0, 0);

      // Headlight Beams
      ctx.fillStyle = 'rgba(254, 240, 138, 0.15)';
      ctx.beginPath();
      ctx.moveTo(-15, -25);
      ctx.lineTo(-40, -160);
      ctx.lineTo(40, -160);
      ctx.lineTo(15, -25);
      ctx.closePath();
      ctx.fill();

      ctx.restore();

      ctx.restore();

      animId = requestAnimationFrame(loop);
    };

    animId = requestAnimationFrame(loop);
    return () => cancelAnimationFrame(animId);
  }, [gameState, car, handleGameOver]);

  const toggleSound = () => {
    const s = sound.toggleSfxMute();
    sound.toggleBgmMute();
    setIsMuted(s);
  };

  return (
    <div className="relative w-full max-w-5xl mx-auto flex flex-col items-center">
      {/* Top Game Bar */}
      <div className="w-full flex items-center justify-between bg-slate-900/90 border border-slate-800 rounded-2xl p-3 sm:p-4 mb-3 backdrop-blur-md shadow-2xl">
        <button
          onClick={onBackToHub}
          className="flex items-center gap-2 px-3 py-1.5 sm:px-4 sm:py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold transition text-xs sm:text-sm"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>{t.backToHub}</span>
        </button>

        {/* Live HUD Dashboard */}
        <div className="flex items-center gap-3 sm:gap-6 text-xs sm:text-sm font-bold">
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Trophy className="w-4 h-4 text-yellow-400" />
            <span className="text-yellow-400 font-pixel">{score}</span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <Gauge className="w-4 h-4 text-cyan-400" />
            <span className="text-cyan-400 font-mono text-base">{speedKmh} <span className="text-xs text-slate-400">{t.racerKmh}</span></span>
          </div>
          <div className="flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-amber-400 font-bold">🪙 {coinsCollected}</span>
          </div>
          <div className="hidden sm:flex items-center gap-1.5 bg-slate-800/80 px-3 py-1.5 rounded-xl border border-slate-700">
            <span className="text-cyan-400 font-bold">💎 {diamondsCollected}</span>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={toggleSound}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
          >
            {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-cyan-400" />}
          </button>
        </div>
      </div>

      {/* Canvas Area Container */}
      <div className="relative w-full aspect-[16/9] max-h-[540px] bg-slate-950 rounded-2xl overflow-hidden border-2 border-cyan-500/40 shadow-2xl">
        <canvas
          ref={canvasRef}
          width={960}
          height={540}
          className="w-full h-full object-cover block"
        />

        {/* Dashboard Gauges (Nitro & HP) */}
        {gameState === 'playing' && (
          <div className="absolute top-4 left-4 flex flex-col gap-2 z-10 pointer-events-none">
            {/* Nitro Gauge */}
            <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-cyan-500/30">
              <Flame className="w-4 h-4 text-cyan-400 fill-cyan-400 animate-pulse" />
              <div className="w-28 sm:w-36 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-blue-500 transition-all duration-100"
                  style={{ width: `${nitroAmount}%` }}
                />
              </div>
              <span className="text-xs font-bold text-cyan-300 font-mono">{t.racerNitro}</span>
            </div>

            {/* Car Armor / HP */}
            <div className="flex items-center gap-2 bg-slate-900/80 backdrop-blur-md px-3 py-1.5 rounded-xl border border-emerald-500/30">
              <Shield className="w-4 h-4 text-emerald-400 fill-emerald-400" />
              <div className="w-28 sm:w-36 h-3 bg-slate-800 rounded-full overflow-hidden border border-slate-700">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-green-600 transition-all duration-200"
                  style={{ width: `${carHp}%` }}
                />
              </div>
              <span className="text-xs font-bold text-emerald-300 font-mono">{carHp}%</span>
            </div>
          </div>
        )}

        {/* Overlay: Menu / Start */}
        {gameState === 'menu' && (
          <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <div className="text-6xl mb-3 animate-float">{car.imageOrEmoji}</div>
            <h2 className="text-2xl sm:text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-blue-400 to-cyan-500 mb-2 font-russo tracking-wide">
              {t.game2Title}
            </h2>
            <p className="text-slate-300 text-xs sm:text-sm max-w-md mb-6 leading-relaxed">
              {t.game2Desc}
            </p>

            <div className="flex flex-wrap items-center justify-center gap-4 mb-6">
              <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300">
                <span className="text-yellow-400 font-bold">{t.highScore}:</span> {highScore}
              </div>
              <div className="px-4 py-2 bg-slate-900 border border-slate-800 rounded-xl text-xs text-slate-300">
                <span className="text-cyan-400 font-bold">{car.name}:</span> Max {car.stats.topSpeed} km/soat
              </div>
            </div>

            <button
              onClick={startGame}
              className="px-8 py-3.5 bg-gradient-to-r from-cyan-500 via-blue-500 to-cyan-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-black text-base sm:text-lg rounded-2xl shadow-xl hover:scale-105 active:scale-95 transition flex items-center gap-3 glow-cyan"
            >
              <Play className="w-5 h-5 fill-slate-950" />
              <span>{t.playNow}</span>
            </button>
          </div>
        )}

        {/* Overlay: Game Over */}
        {gameState === 'gameover' && (
          <div className="absolute inset-0 bg-slate-950/85 backdrop-blur-md flex flex-col items-center justify-center p-6 text-center z-20">
            <h2 className="text-3xl sm:text-5xl font-black text-rose-500 mb-2 font-russo">
              {t.gameOver}
            </h2>
            <p className="text-slate-400 text-sm mb-6 font-cyber">
              {distanceM} metr masofani yuqori tezlikda bosib o'tdingiz!
            </p>

            <div className="grid grid-cols-3 gap-3 max-w-md w-full mb-6">
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.score}</div>
                <div className="text-lg font-bold text-yellow-400 font-pixel">{score}</div>
              </div>
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.coins}</div>
                <div className="text-lg font-bold text-amber-400">+{coinsCollected} 🪙</div>
              </div>
              <div className="bg-slate-900/90 border border-slate-800 p-3 rounded-xl">
                <div className="text-xs text-slate-400">{t.diamonds}</div>
                <div className="text-lg font-bold text-cyan-400">+{diamondsCollected} 💎</div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={startGame}
                className="px-6 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white font-bold rounded-xl shadow-lg hover:scale-105 transition flex items-center gap-2"
              >
                <RotateCcw className="w-4 h-4" />
                <span>{t.restart}</span>
              </button>
              <button
                onClick={onBackToHub}
                className="px-6 py-3 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold rounded-xl transition"
              >
                {t.backToHub}
              </button>
            </div>
          </div>
        )}
      </div>

      {/* Mobile Touch Action Buttons */}
      <div className="w-full mt-4 grid grid-cols-3 gap-2.5">
        <button
          onPointerDown={() => { engineRef.current.keys.left = true; }}
          onPointerUp={() => { engineRef.current.keys.left = false; }}
          onPointerLeave={() => { engineRef.current.keys.left = false; }}
          className="p-4 bg-slate-900/90 border border-slate-800 hover:border-cyan-500 text-slate-200 active:bg-cyan-950 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-2xl">⬅️</span>
          <span className="text-xs font-bold text-cyan-400 mt-1">CHAPGA (A)</span>
        </button>

        <button
          onPointerDown={() => { engineRef.current.keys.nitro = true; }}
          onPointerUp={() => { engineRef.current.keys.nitro = false; }}
          onPointerLeave={() => { engineRef.current.keys.nitro = false; }}
          className="p-4 bg-gradient-to-b from-cyan-900/80 to-blue-900/80 border border-cyan-500 text-white active:scale-95 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-2xl">🔥</span>
          <span className="text-xs font-bold text-cyan-300 mt-1">NITRO TURBO!</span>
        </button>

        <button
          onPointerDown={() => { engineRef.current.keys.right = true; }}
          onPointerUp={() => { engineRef.current.keys.right = false; }}
          onPointerLeave={() => { engineRef.current.keys.right = false; }}
          className="p-4 bg-slate-900/90 border border-slate-800 hover:border-cyan-500 text-slate-200 active:bg-cyan-950 rounded-2xl flex flex-col items-center justify-center shadow-lg transition"
        >
          <span className="text-2xl">➡️</span>
          <span className="text-xs font-bold text-cyan-400 mt-1">O'NGGA (D)</span>
        </button>
      </div>

      {/* Keyboard Controls Guide */}
      <div className="w-full mt-3 p-3 bg-slate-900/50 border border-slate-800/80 rounded-xl text-center text-xs text-slate-400">
        <span className="text-slate-300 font-bold">{t.controls}: </span>
        {t.racerControls}
      </div>
    </div>
  );
};
