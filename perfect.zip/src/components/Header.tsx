import React from 'react';
import { PlayerProfile, Language } from '../types/game';
import { getTranslation } from '../services/localization';
import { Sparkles, Trophy, Settings, ShoppingBag, Target, Award, User } from 'lucide-react';

interface HeaderProps {
  profile: PlayerProfile;
  language: Language;
  onOpenShop: () => void;
  onOpenWheel: () => void;
  onOpenQuests: () => void;
  onOpenAchievements: () => void;
  onOpenLeaderboard: () => void;
  onOpenProfile: () => void;
  onOpenSettings: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  profile,
  language,
  onOpenShop,
  onOpenWheel,
  onOpenQuests,
  onOpenAchievements,
  onOpenLeaderboard,
  onOpenProfile,
  onOpenSettings
}) => {
  const t = getTranslation(language);

  return (
    <header className="w-full bg-slate-900/90 border-b border-slate-800 backdrop-blur-md sticky top-0 z-40 px-3 sm:px-6 py-2.5 sm:py-3 shadow-xl">
      <div className="max-w-7xl mx-auto flex items-center justify-between gap-2 sm:gap-4">
        {/* Brand Logo & Title */}
        <div className="flex items-center gap-2.5 sm:gap-3 cursor-pointer" onClick={onOpenProfile}>
          <div className="w-9 h-9 sm:w-11 sm:h-11 rounded-2xl bg-gradient-to-tr from-amber-500 via-yellow-400 to-amber-600 flex items-center justify-center text-xl sm:text-2xl shadow-lg glow-gold shrink-0">
            {profile.avatar}
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <h1 className="font-black text-sm sm:text-lg text-transparent bg-clip-text bg-gradient-to-r from-yellow-400 via-amber-300 to-yellow-500 font-russo tracking-wide">
                {t.appTitle}
              </h1>
              <span className="hidden md:inline-block px-2 py-0.5 bg-yellow-500/10 text-yellow-400 border border-yellow-500/30 rounded-full text-[10px] font-bold font-mono">
                v2.0
              </span>
            </div>
            <p className="text-[11px] text-slate-400 hidden sm:block font-cyber">
              {profile.name} • <span className="text-amber-400 font-bold">{t.level} {profile.level}</span>
            </p>
          </div>
        </div>

        {/* Currency & Action Badges */}
        <div className="flex items-center gap-1.5 sm:gap-3">
          {/* Coins Badge */}
          <div
            onClick={onOpenShop}
            className="flex items-center gap-1.5 bg-slate-950/80 hover:bg-slate-800 border border-amber-500/30 px-2.5 sm:px-3.5 py-1.5 rounded-xl cursor-pointer transition shadow-md"
          >
            <span className="text-sm sm:text-base">🪙</span>
            <span className="text-xs sm:text-sm font-extrabold text-amber-400 font-mono">
              {profile.coins.toLocaleString()}
            </span>
          </div>

          {/* Diamonds Badge */}
          <div
            onClick={onOpenShop}
            className="flex items-center gap-1.5 bg-slate-950/80 hover:bg-slate-800 border border-cyan-500/30 px-2.5 sm:px-3.5 py-1.5 rounded-xl cursor-pointer transition shadow-md"
          >
            <span className="text-sm sm:text-base">💎</span>
            <span className="text-xs sm:text-sm font-extrabold text-cyan-400 font-mono">
              {profile.diamonds.toLocaleString()}
            </span>
          </div>

          {/* Wheel Action */}
          <button
            onClick={onOpenWheel}
            className="relative p-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 rounded-xl transition shadow-md font-bold text-xs flex items-center gap-1.5"
            title={t.wheel}
          >
            <Sparkles className="w-4 h-4 fill-slate-950" />
            <span className="hidden lg:inline">{t.wheel}</span>
            {profile.spinsAvailable > 0 && (
              <span className="absolute -top-1 -right-1 w-3 h-3 bg-red-500 rounded-full animate-ping" />
            )}
          </button>

          {/* Quests Button */}
          <button
            onClick={onOpenQuests}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-cyan-400 rounded-xl transition"
            title={t.quests}
          >
            <Target className="w-4 h-4" />
          </button>

          {/* Achievements Button */}
          <button
            onClick={onOpenAchievements}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-yellow-400 rounded-xl transition"
            title={t.achievements}
          >
            <Award className="w-4 h-4" />
          </button>

          {/* Leaderboard Button */}
          <button
            onClick={onOpenLeaderboard}
            className="hidden sm:flex p-2 bg-slate-800 hover:bg-slate-700 text-amber-400 rounded-xl transition"
            title={t.leaderboard}
          >
            <Trophy className="w-4 h-4" />
          </button>

          {/* Shop Button */}
          <button
            onClick={onOpenShop}
            className="hidden sm:flex p-2 bg-slate-800 hover:bg-slate-700 text-pink-400 rounded-xl transition"
            title={t.shop}
          >
            <ShoppingBag className="w-4 h-4" />
          </button>

          {/* Profile Button */}
          <button
            onClick={onOpenProfile}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
            title={t.profile}
          >
            <User className="w-4 h-4" />
          </button>

          {/* Settings Button */}
          <button
            onClick={onOpenSettings}
            className="p-2 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition"
            title={t.settings}
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>
    </header>
  );
};
