import React, { useState } from 'react';
import { PlayerProfile, GameId, Language } from '../../types/game';
import { storage, MOCK_LEADERBOARDS } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, Trophy } from 'lucide-react';

interface LeaderboardModalProps {
  profile: PlayerProfile;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
}

export const LeaderboardModal: React.FC<LeaderboardModalProps> = ({
  profile,
  language,
  isOpen,
  onClose
}) => {
  const t = getTranslation(language);
  const [selectedGame, setSelectedGame] = useState<GameId>('runner');

  if (!isOpen) return null;

  const stats = storage.getStats();
  const myHighScore = selectedGame === 'runner'
    ? stats.runnerHighScore
    : selectedGame === 'racer'
    ? stats.racerHighScore
    : selectedGame === 'merge'
    ? stats.mergeHighScore
    : selectedGame === 'archer'
    ? stats.archerHighScore
    : stats.brainHighScore;

  const entries = [
    ...MOCK_LEADERBOARDS,
    { rank: 6, name: profile.name, avatar: profile.avatar, score: myHighScore, gameId: selectedGame, date: 'Siz' }
  ].sort((a, b) => b.score - a.score).map((entry, idx) => ({ ...entry, rank: idx + 1 }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-2xl max-h-[85vh] bg-slate-900 border-2 border-slate-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-yellow-500/10 text-yellow-400 rounded-2xl">
              <Trophy className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-100 font-russo">{t.leaderboard}</h2>
              <p className="text-xs text-slate-400">{t.leaderboardTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Game Filter Selector */}
        <div className="p-3 bg-slate-950/40 border-b border-slate-800 flex gap-2 overflow-x-auto">
          <button
            onClick={() => setSelectedGame('runner')}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition shrink-0 ${
              selectedGame === 'runner' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🏃 Runner
          </button>
          <button
            onClick={() => setSelectedGame('racer')}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition shrink-0 ${
              selectedGame === 'racer' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🏎️ Poyga
          </button>
          <button
            onClick={() => setSelectedGame('merge')}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition shrink-0 ${
              selectedGame === 'merge' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🍉 Suika
          </button>
          <button
            onClick={() => setSelectedGame('archer')}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition shrink-0 ${
              selectedGame === 'archer' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🏹 Mergan
          </button>
          <button
            onClick={() => setSelectedGame('brain')}
            className={`px-3 py-1.5 rounded-xl font-bold text-xs transition shrink-0 ${
              selectedGame === 'brain' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🧠 Zehn
          </button>
        </div>

        {/* Rankings List */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex flex-col gap-2.5">
          {entries.map((item) => {
            const isMe = item.name === profile.name;

            return (
              <div
                key={item.rank}
                className={`p-3.5 rounded-2xl border flex items-center justify-between gap-3 transition ${
                  isMe
                    ? 'bg-amber-950/40 border-amber-500/60 glow-gold'
                    : item.rank === 1
                    ? 'bg-yellow-950/20 border-yellow-500/40'
                    : item.rank === 2
                    ? 'bg-slate-800/40 border-slate-700'
                    : item.rank === 3
                    ? 'bg-amber-900/20 border-amber-800'
                    : 'bg-slate-950/50 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center font-bold font-mono text-sm">
                    {item.rank === 1 ? '🥇' : item.rank === 2 ? '🥈' : item.rank === 3 ? '🥉' : `#${item.rank}`}
                  </div>
                  <span className="text-2xl">{item.avatar}</span>
                  <div>
                    <div className="font-bold text-sm text-slate-100 flex items-center gap-1.5">
                      <span>{item.name}</span>
                      {isMe && <span className="text-[10px] bg-amber-500 text-slate-950 px-1.5 py-0.5 rounded font-black">SIZ</span>}
                    </div>
                    <div className="text-[11px] text-slate-400">{item.date}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-bold text-base text-yellow-400 font-pixel">{item.score}</div>
                  <div className="text-[10px] text-slate-400">{t.score}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
