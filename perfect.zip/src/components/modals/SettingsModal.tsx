import React, { useState } from 'react';
import { Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, Settings, Volume2, Music, Trash2 } from 'lucide-react';

interface SettingsModalProps {
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onLanguageChange: (lang: Language) => void;
  onResetAllData: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  language,
  isOpen,
  onClose,
  onLanguageChange,
  onResetAllData
}) => {
  const t = getTranslation(language);
  const muteState = sound.getMuteState();

  const [sfxMuted, setSfxMuted] = useState(muteState.sfx);
  const [bgmMuted, setBgmMuted] = useState(muteState.bgm);

  if (!isOpen) return null;

  const toggleSfx = () => {
    const s = sound.toggleSfxMute();
    setSfxMuted(s);
  };

  const toggleBgm = () => {
    const s = sound.toggleBgmMute();
    setBgmMuted(s);
  };

  const handleReset = () => {
    if (window.confirm(t.resetConfirm)) {
      storage.resetAll();
      onResetAllData();
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-900 border-2 border-slate-800 rounded-3xl p-6 flex flex-col relative shadow-2xl">
        {/* Header */}
        <div className="w-full flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-slate-800 text-slate-300 rounded-xl">
              <Settings className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-slate-100 font-russo">{t.settings}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Audio Toggles */}
        <div className="flex flex-col gap-3 mb-6">
          <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
                <Volume2 className="w-5 h-5" />
              </div>
              <span className="font-bold text-sm text-slate-200">{t.soundEffects}</span>
            </div>
            <button
              onClick={toggleSfx}
              className={`px-4 py-1.5 rounded-xl font-bold text-xs transition ${
                sfxMuted ? 'bg-slate-800 text-slate-500' : 'bg-cyan-500 text-slate-950'
              }`}
            >
              {sfxMuted ? 'O\'chiq' : 'Yoniq'}
            </button>
          </div>

          <div className="p-3 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-pink-500/10 text-pink-400 rounded-xl">
                <Music className="w-5 h-5" />
              </div>
              <span className="font-bold text-sm text-slate-200">{t.bgmMusic}</span>
            </div>
            <button
              onClick={toggleBgm}
              className={`px-4 py-1.5 rounded-xl font-bold text-xs transition ${
                bgmMuted ? 'bg-slate-800 text-slate-500' : 'bg-pink-500 text-slate-950'
              }`}
            >
              {bgmMuted ? 'O\'chiq' : 'Yoniq'}
            </button>
          </div>
        </div>

        {/* Language Selector */}
        <div className="mb-6">
          <label className="block text-xs font-bold text-slate-400 mb-2">{t.language}</label>
          <div className="grid grid-cols-2 gap-2">
            <button
              onClick={() => onLanguageChange('uz')}
              className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                language === 'uz'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🇺🇿 O'zbekcha (Lotin)</span>
            </button>
            <button
              onClick={() => onLanguageChange('uz_cyr')}
              className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                language === 'uz_cyr'
                  ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🇺🇿 Ўзбекча (Кирилл)</span>
            </button>
            <button
              onClick={() => onLanguageChange('en')}
              className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                language === 'en'
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🇬🇧 English</span>
            </button>
            <button
              onClick={() => onLanguageChange('ru')}
              className={`p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-2 ${
                language === 'ru'
                  ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:text-slate-200'
              }`}
            >
              <span>🇷🇺 Русский</span>
            </button>
          </div>
        </div>

        {/* Reset Data */}
        <div className="pt-2 border-t border-slate-800">
          <button
            onClick={handleReset}
            className="w-full py-2.5 bg-rose-500/10 hover:bg-rose-500/20 text-rose-400 border border-rose-500/30 rounded-xl font-bold text-xs transition flex items-center justify-center gap-2"
          >
            <Trash2 className="w-4 h-4" />
            <span>{t.resetData}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
