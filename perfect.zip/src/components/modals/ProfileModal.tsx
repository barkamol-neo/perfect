import React, { useState } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, User, Check } from 'lucide-react';

interface ProfileModalProps {
  profile: PlayerProfile;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onUpdateProfile: (profile: PlayerProfile) => void;
}

const AVATAR_OPTIONS = ['🗡️', '🏹', '👑', '🔥', '⚡', '⏳', '🦅', '🦾', '🚀', '🏎️', '🐉', '🐯'];

export const ProfileModal: React.FC<ProfileModalProps> = ({
  profile,
  language,
  isOpen,
  onClose,
  onUpdateProfile
}) => {
  const t = getTranslation(language);
  const [name, setName] = useState(profile.name);
  const [selectedAvatar, setSelectedAvatar] = useState(profile.avatar);

  if (!isOpen) return null;

  const stats = storage.getStats();
  const currentLevelXp = profile.xp % 500;

  const handleSave = () => {
    const newProfile = {
      ...profile,
      name: name.trim() || 'Qahramon',
      avatar: selectedAvatar
    };
    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-md bg-slate-900 border-2 border-slate-800 rounded-3xl p-6 flex flex-col relative shadow-2xl">
        {/* Header */}
        <div className="w-full flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-cyan-500/10 text-cyan-400 rounded-xl">
              <User className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-slate-100 font-russo">{t.profile}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Level & XP card */}
        <div className="p-4 bg-slate-950 border border-slate-800 rounded-2xl mb-4 flex items-center gap-4">
          <div className="text-4xl p-2 bg-slate-900 rounded-2xl border border-slate-800">
            {selectedAvatar}
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between mb-1">
              <span className="text-sm font-bold text-slate-200">{profile.name}</span>
              <span className="text-xs font-bold text-amber-400 font-mono">{t.level} {profile.level}</span>
            </div>
            <div className="w-full h-2.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-amber-500 to-yellow-400"
                style={{ width: `${Math.min(100, (currentLevelXp / 500) * 100)}%` }}
              />
            </div>
            <div className="text-[10px] text-slate-400 mt-1 text-right">
              {currentLevelXp} / 500 {t.xp} (Jami: {profile.xp})
            </div>
          </div>
        </div>

        {/* Edit Nickname */}
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-400 mb-1.5">Ism / Nikneym</label>
          <input
            type="text"
            value={name}
            maxLength={18}
            onChange={(e) => setName(e.target.value)}
            className="w-full px-4 py-2.5 bg-slate-950 border border-slate-800 rounded-xl text-slate-100 font-bold text-sm focus:border-cyan-500 focus:outline-none"
          />
        </div>

        {/* Avatar Picker */}
        <div className="mb-4">
          <label className="block text-xs font-bold text-slate-400 mb-2">Avatar Tanlang</label>
          <div className="grid grid-cols-6 gap-2">
            {AVATAR_OPTIONS.map((av) => (
              <button
                key={av}
                onClick={() => setSelectedAvatar(av)}
                className={`p-2.5 text-2xl rounded-xl border transition flex items-center justify-center ${
                  selectedAvatar === av
                    ? 'bg-cyan-950/80 border-cyan-400 shadow-md scale-105'
                    : 'bg-slate-950 border-slate-800 hover:border-slate-700'
                }`}
              >
                {av}
              </button>
            ))}
          </div>
        </div>

        {/* Stats Summary */}
        <div className="grid grid-cols-2 gap-2 mb-6 text-xs">
          <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-300">
            <span className="text-slate-500 block">Jami o'yinlar:</span>
            <span className="font-bold text-sm text-cyan-400">{stats.totalGamesPlayed}</span>
          </div>
          <div className="p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-300">
            <span className="text-slate-500 block">Jami tangalar:</span>
            <span className="font-bold text-sm text-amber-400">{stats.totalCoinsEarned} 🪙</span>
          </div>
        </div>

        <button
          onClick={handleSave}
          className="w-full py-3 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold rounded-xl shadow-lg transition flex items-center justify-center gap-2 active:scale-95"
        >
          <Check className="w-4 h-4" />
          <span>Saqlash</span>
        </button>
      </div>
    </div>
  );
};
