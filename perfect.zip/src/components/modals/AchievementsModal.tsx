import React, { useState, useEffect } from 'react';
import { PlayerProfile, Achievement, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, Award, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

interface AchievementsModalProps {
  profile: PlayerProfile;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onUpdateProfile: (profile: PlayerProfile) => void;
}

export const AchievementsModal: React.FC<AchievementsModalProps> = ({
  language,
  isOpen,
  onClose,
  onUpdateProfile
}) => {
  const t = getTranslation(language);
  const [achievements, setAchievements] = useState<Achievement[]>([]);

  useEffect(() => {
    if (isOpen) {
      setAchievements(storage.getAchievements());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClaim = (achId: string, rewardAmount: number, rewardType: 'coins' | 'diamonds') => {
    sound.playPowerup();
    confetti({ particleCount: 50, spread: 70 });

    const updated = storage.addCoinsAndDiamonds(
      rewardType === 'coins' ? rewardAmount : 0,
      rewardType === 'diamonds' ? rewardAmount : 0
    );

    const list = achievements.map(a => {
      if (a.id === achId) {
        return { ...a, progress: a.maxProgress, isUnlocked: true };
      }
      return a;
    });

    storage.saveAchievements(list);
    setAchievements(list);
    onUpdateProfile(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-2xl max-h-[85vh] bg-slate-900 border-2 border-slate-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-yellow-500/10 text-yellow-400 rounded-2xl">
              <Award className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-100 font-russo">{t.achievements}</h2>
              <p className="text-xs text-slate-400">{t.achievementsTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content List */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex flex-col gap-3">
          {achievements.map((ach) => {
            const isDone = ach.progress >= ach.maxProgress;

            return (
              <div
                key={ach.id}
                className={`p-4 rounded-2xl border flex items-center justify-between gap-4 transition ${
                  ach.isUnlocked
                    ? 'bg-slate-950/90 border-slate-800 opacity-80'
                    : isDone
                    ? 'bg-amber-950/30 border-amber-500/50 glow-gold'
                    : 'bg-slate-950/50 border-slate-800'
                }`}
              >
                <div className="flex items-center gap-3.5">
                  <span className="text-3xl sm:text-4xl p-2 bg-slate-900 rounded-2xl border border-slate-800">
                    {ach.icon}
                  </span>
                  <div>
                    <h3 className="font-bold text-sm sm:text-base text-slate-100">{ach.title}</h3>
                    <p className="text-xs text-slate-400 mb-2">{ach.description}</p>

                    {/* Progress Bar */}
                    <div className="flex items-center gap-2">
                      <div className="w-28 sm:w-44 h-2 bg-slate-800 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-gradient-to-r from-yellow-500 to-amber-500"
                          style={{ width: `${Math.min(100, (ach.progress / ach.maxProgress) * 100)}%` }}
                        />
                      </div>
                      <span className="text-[11px] text-slate-400 font-mono">
                        {ach.progress} / {ach.maxProgress}
                      </span>
                    </div>
                  </div>
                </div>

                <div>
                  {ach.isUnlocked ? (
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl font-bold text-xs">
                      <Check className="w-4 h-4" />
                      <span>{t.claimed}</span>
                    </div>
                  ) : isDone ? (
                    <button
                      onClick={() => handleClaim(ach.id, ach.rewardAmount, ach.rewardType)}
                      className="px-4 py-2 bg-gradient-to-r from-amber-500 to-yellow-500 hover:from-amber-400 hover:to-yellow-400 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition active:scale-95"
                    >
                      {t.claim}: +{ach.rewardAmount} {ach.rewardType === 'coins' ? '🪙' : '💎'}
                    </button>
                  ) : (
                    <div className="text-xs font-bold text-slate-500 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                      +{ach.rewardAmount} {ach.rewardType === 'coins' ? '🪙' : '💎'}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
