import React, { useState } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage, HEROES_CATALOG, WEAPONS_CATALOG, CARS_CATALOG, PETS_CATALOG } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, Check, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface ShopModalProps {
  profile: PlayerProfile;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onUpdateProfile: (profile: PlayerProfile) => void;
}

type ShopTab = 'heroes' | 'weapons' | 'cars' | 'pets';

export const ShopModal: React.FC<ShopModalProps> = ({
  profile,
  language,
  isOpen,
  onClose,
  onUpdateProfile
}) => {
  const t = getTranslation(language);
  const [tab, setTab] = useState<ShopTab>('heroes');

  if (!isOpen) return null;

  const handleBuyHero = (heroId: string, price: number, currency: 'coins' | 'diamonds') => {
    if (currency === 'coins' && profile.coins < price) return;
    if (currency === 'diamonds' && profile.diamonds < price) return;

    sound.playPowerup();
    confetti({ particleCount: 40, spread: 60 });

    const newProfile = { ...profile };
    if (currency === 'coins') newProfile.coins -= price;
    else newProfile.diamonds -= price;

    newProfile.unlockedHeroIds.push(heroId);
    newProfile.selectedHeroId = heroId;

    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleSelectHero = (heroId: string) => {
    sound.playClick();
    const newProfile = { ...profile, selectedHeroId: heroId };
    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleBuyWeapon = (weaponId: string, price: number, currency: 'coins' | 'diamonds') => {
    if (currency === 'coins' && profile.coins < price) return;
    if (currency === 'diamonds' && profile.diamonds < price) return;

    sound.playPowerup();
    confetti({ particleCount: 40, spread: 60 });

    const newProfile = { ...profile };
    if (currency === 'coins') newProfile.coins -= price;
    else newProfile.diamonds -= price;

    newProfile.unlockedWeaponIds.push(weaponId);
    newProfile.selectedWeaponId = weaponId;

    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleSelectWeapon = (weaponId: string) => {
    sound.playClick();
    const newProfile = { ...profile, selectedWeaponId: weaponId };
    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleBuyCar = (carId: string, price: number, currency: 'coins' | 'diamonds') => {
    if (currency === 'coins' && profile.coins < price) return;
    if (currency === 'diamonds' && profile.diamonds < price) return;

    sound.playPowerup();
    confetti({ particleCount: 40, spread: 60 });

    const newProfile = { ...profile };
    if (currency === 'coins') newProfile.coins -= price;
    else newProfile.diamonds -= price;

    newProfile.unlockedCarIds.push(carId);
    newProfile.selectedCarId = carId;

    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleSelectCar = (carId: string) => {
    sound.playClick();
    const newProfile = { ...profile, selectedCarId: carId };
    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleBuyPet = (petId: string, price: number, currency: 'coins' | 'diamonds') => {
    if (currency === 'coins' && profile.coins < price) return;
    if (currency === 'diamonds' && profile.diamonds < price) return;

    sound.playPowerup();
    confetti({ particleCount: 40, spread: 60 });

    const newProfile = { ...profile };
    if (currency === 'coins') newProfile.coins -= price;
    else newProfile.diamonds -= price;

    newProfile.unlockedPetIds.push(petId);
    newProfile.selectedPetId = petId;

    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  const handleSelectPet = (petId: string | null) => {
    sound.playClick();
    const newProfile = { ...profile, selectedPetId: petId };
    storage.saveProfile(newProfile);
    onUpdateProfile(newProfile);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-4xl max-h-[90vh] bg-slate-900 border-2 border-slate-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-amber-500/10 text-amber-400 rounded-2xl">
              <Sparkles className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-100 font-russo">{t.shop}</h2>
              <p className="text-xs text-slate-400">Qahramonlar, qurollar va maxsus mashinalar</p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800 text-xs sm:text-sm font-bold">
              <span className="text-amber-400">🪙 {profile.coins}</span>
              <span className="text-cyan-400">💎 {profile.diamonds}</span>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Tab Buttons */}
        <div className="flex border-b border-slate-800 bg-slate-950/40 p-2 gap-2 overflow-x-auto">
          <button
            onClick={() => setTab('heroes')}
            className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
              tab === 'heroes' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🗡️ {t.heroes}
          </button>
          <button
            onClick={() => setTab('weapons')}
            className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
              tab === 'weapons' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            ⚔️ {t.weapons}
          </button>
          <button
            onClick={() => setTab('cars')}
            className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
              tab === 'cars' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🏎️ {t.cars}
          </button>
          <button
            onClick={() => setTab('pets')}
            className={`px-4 py-2 rounded-xl font-bold text-xs sm:text-sm transition shrink-0 ${
              tab === 'pets' ? 'bg-amber-500 text-slate-950' : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            🦅 {t.pets}
          </button>
        </div>

        {/* Catalog Grid Content */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {/* 1. HEROES */}
          {tab === 'heroes' && HEROES_CATALOG.map((hero) => {
            const isUnlocked = profile.unlockedHeroIds.includes(hero.id);
            const isSelected = profile.selectedHeroId === hero.id;
            const canAfford = hero.currency === 'coins' ? profile.coins >= hero.price : profile.diamonds >= hero.price;

            return (
              <div
                key={hero.id}
                className={`p-4 rounded-2xl border flex flex-col justify-between transition ${
                  isSelected
                    ? 'bg-amber-950/40 border-amber-400 shadow-lg glow-gold'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-4xl">{hero.avatar}</span>
                    <span className="text-xs px-2.5 py-1 bg-slate-900 rounded-lg text-slate-300 font-mono">
                      HP {hero.stats.health}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-100">{hero.name}</h3>
                  <p className="text-xs text-amber-400 font-medium mb-1.5">{hero.title}</p>
                  <p className="text-xs text-slate-400 mb-3 leading-relaxed">{hero.description}</p>

                  <div className="text-xs text-cyan-400 bg-cyan-950/40 p-2 rounded-xl border border-cyan-800/40 mb-3">
                    ✨ {hero.specialSkill}
                  </div>
                </div>

                <div>
                  {isSelected ? (
                    <button className="w-full py-2 bg-amber-500/20 text-amber-300 border border-amber-500/50 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-default">
                      <Check className="w-4 h-4" />
                      <span>{t.selected}</span>
                    </button>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => handleSelectHero(hero.id)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition"
                    >
                      {t.select}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBuyHero(hero.id, hero.price, hero.currency)}
                      disabled={!canAfford}
                      className={`w-full py-2 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md'
                          : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <span>{t.buy}: {hero.price} {hero.currency === 'coins' ? '🪙' : '💎'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* 2. WEAPONS */}
          {tab === 'weapons' && WEAPONS_CATALOG.map((weapon) => {
            const isUnlocked = profile.unlockedWeaponIds.includes(weapon.id);
            const isSelected = profile.selectedWeaponId === weapon.id;
            const canAfford = weapon.currency === 'coins' ? profile.coins >= weapon.price : profile.diamonds >= weapon.price;

            return (
              <div
                key={weapon.id}
                className={`p-4 rounded-2xl border flex flex-col justify-between transition ${
                  isSelected
                    ? 'bg-amber-950/40 border-amber-400 shadow-lg glow-gold'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-3xl">{weapon.icon}</span>
                    <span className="text-xs px-2.5 py-1 bg-slate-900 rounded-lg text-rose-400 font-mono font-bold">
                      Zarba +{weapon.damage}
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-100">{weapon.name}</h3>
                  <p className="text-xs text-slate-400 mb-3">{weapon.description}</p>
                  <p className="text-xs text-cyan-400 mb-4">💥 {weapon.effectDescription}</p>
                </div>

                <div>
                  {isSelected ? (
                    <button className="w-full py-2 bg-amber-500/20 text-amber-300 border border-amber-500/50 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-default">
                      <Check className="w-4 h-4" />
                      <span>{t.selected}</span>
                    </button>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => handleSelectWeapon(weapon.id)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition"
                    >
                      {t.select}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBuyWeapon(weapon.id, weapon.price, weapon.currency)}
                      disabled={!canAfford}
                      className={`w-full py-2 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-amber-500 hover:bg-amber-400 text-slate-950 shadow-md'
                          : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <span>{t.buy}: {weapon.price} {weapon.currency === 'coins' ? '🪙' : '💎'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* 3. CARS */}
          {tab === 'cars' && CARS_CATALOG.map((car) => {
            const isUnlocked = profile.unlockedCarIds.includes(car.id);
            const isSelected = profile.selectedCarId === car.id;
            const canAfford = car.currency === 'coins' ? profile.coins >= car.price : profile.diamonds >= car.price;

            return (
              <div
                key={car.id}
                className={`p-4 rounded-2xl border flex flex-col justify-between transition ${
                  isSelected
                    ? 'bg-cyan-950/40 border-cyan-400 shadow-lg glow-cyan'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-4xl">{car.imageOrEmoji}</span>
                    <span className="text-xs px-2.5 py-1 bg-slate-900 rounded-lg text-cyan-400 font-mono font-bold">
                      {car.stats.topSpeed} km/h
                    </span>
                  </div>

                  <h3 className="font-bold text-base text-slate-100">{car.name}</h3>
                  <p className="text-xs text-cyan-400 font-medium mb-1">{car.subtitle}</p>
                  <p className="text-xs text-slate-400 mb-4">{car.description}</p>
                </div>

                <div>
                  {isSelected ? (
                    <button className="w-full py-2 bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5 cursor-default">
                      <Check className="w-4 h-4" />
                      <span>{t.selected}</span>
                    </button>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => handleSelectCar(car.id)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition"
                    >
                      {t.select}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBuyCar(car.id, car.price, car.currency)}
                      disabled={!canAfford}
                      className={`w-full py-2 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 shadow-md'
                          : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <span>{t.buy}: {car.price} {car.currency === 'coins' ? '🪙' : '💎'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}

          {/* 4. PETS */}
          {tab === 'pets' && PETS_CATALOG.map((pet) => {
            const isUnlocked = profile.unlockedPetIds.includes(pet.id);
            const isSelected = profile.selectedPetId === pet.id;
            const canAfford = pet.currency === 'coins' ? profile.coins >= pet.price : profile.diamonds >= pet.price;

            return (
              <div
                key={pet.id}
                className={`p-4 rounded-2xl border flex flex-col justify-between transition ${
                  isSelected
                    ? 'bg-pink-950/40 border-pink-400 shadow-lg glow-pink'
                    : 'bg-slate-950/70 border-slate-800'
                }`}
              >
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-4xl">{pet.emoji}</span>
                  </div>

                  <h3 className="font-bold text-base text-slate-100">{pet.name}</h3>
                  <p className="text-xs text-slate-400 mb-2">{pet.description}</p>
                  <p className="text-xs text-pink-400 mb-4 font-semibold">✨ {pet.perk}</p>
                </div>

                <div>
                  {isSelected ? (
                    <button
                      onClick={() => handleSelectPet(null)}
                      className="w-full py-2 bg-pink-500/20 text-pink-300 border border-pink-500/50 rounded-xl font-bold text-xs flex items-center justify-center gap-1.5"
                    >
                      <Check className="w-4 h-4" />
                      <span>Yechish</span>
                    </button>
                  ) : isUnlocked ? (
                    <button
                      onClick={() => handleSelectPet(pet.id)}
                      className="w-full py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-xl font-bold text-xs transition"
                    >
                      {t.select}
                    </button>
                  ) : (
                    <button
                      onClick={() => handleBuyPet(pet.id, pet.price, pet.currency)}
                      disabled={!canAfford}
                      className={`w-full py-2 rounded-xl font-bold text-xs transition flex items-center justify-center gap-1.5 ${
                        canAfford
                          ? 'bg-pink-500 hover:bg-pink-400 text-slate-950 shadow-md'
                          : 'bg-slate-800/60 text-slate-500 cursor-not-allowed'
                      }`}
                    >
                      <span>{t.buy}: {pet.price} {pet.currency === 'coins' ? '🪙' : '💎'}</span>
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
