import React, { useState, useRef } from 'react';
import { PlayerProfile, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface LuckyWheelModalProps {
  profile: PlayerProfile;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onUpdateProfile: (profile: PlayerProfile) => void;
}

const WHEEL_PRIZES = [
  { label: '100 Tangalar', type: 'coins', amount: 100, icon: '🪙', color: '#f59e0b' },
  { label: '2 Olmos', type: 'diamonds', amount: 2, icon: '💎', color: '#06b6d4' },
  { label: '250 Tangalar', type: 'coins', amount: 250, icon: '🪙', color: '#10b981' },
  { label: '500 Tangalar', type: 'coins', amount: 500, icon: '🪙', color: '#8b5cf6' },
  { label: '5 Olmos', type: 'diamonds', amount: 5, icon: '💎', color: '#ec4899' },
  { label: '1,000 Tangalar', type: 'coins', amount: 1000, icon: '💰', color: '#f97316' },
  { label: '2,000 Tangalar', type: 'coins', amount: 2000, icon: '👑', color: '#eab308' },
  { label: '15 Olmos!', type: 'diamonds', amount: 15, icon: '💎👑', color: '#3b82f6' },
];

export const LuckyWheelModal: React.FC<LuckyWheelModalProps> = ({
  profile,
  language,
  isOpen,
  onClose,
  onUpdateProfile
}) => {
  const t = getTranslation(language);
  const [isSpinning, setIsSpinning] = useState(false);
  const [rotation, setRotation] = useState(0);
  const [wonPrize, setWonPrize] = useState<typeof WHEEL_PRIZES[0] | null>(null);

  const wheelRef = useRef<HTMLDivElement | null>(null);

  if (!isOpen) return null;

  const costPerSpin = 150;
  const canFreeSpin = profile.spinsAvailable > 0;
  const canPaidSpin = profile.coins >= costPerSpin;

  const handleSpin = () => {
    if (isSpinning) return;
    if (!canFreeSpin && !canPaidSpin) return;

    setIsSpinning(true);
    setWonPrize(null);

    // Deduct cost or free spin
    const newProfile = { ...profile };
    if (canFreeSpin) {
      newProfile.spinsAvailable -= 1;
    } else {
      newProfile.coins -= costPerSpin;
    }

    // Pick random prize index (0 to 7)
    const prizeIndex = Math.floor(Math.random() * WHEEL_PRIZES.length);
    const prize = WHEEL_PRIZES[prizeIndex];

    const sliceAngle = 360 / WHEEL_PRIZES.length;
    // Calculate final rotation (at least 5 full 360 spins + target angle)
    const extraSpins = 360 * 6;
    const targetAngle = 360 - (prizeIndex * sliceAngle + sliceAngle / 2);
    const finalRot = rotation + extraSpins + (targetAngle - (rotation % 360));

    setRotation(finalRot);

    // Play tick sounds at intervals
    const tickInterval = setInterval(() => {
      sound.playWheelSpinTick();
    }, 150);

    setTimeout(() => {
      clearInterval(tickInterval);
      setIsSpinning(false);
      setWonPrize(prize);

      // Reward player
      if (prize.type === 'coins') {
        newProfile.coins += prize.amount;
      } else {
        newProfile.diamonds += prize.amount;
      }

      storage.saveProfile(newProfile);
      onUpdateProfile(newProfile);

      sound.playVictory();
      confetti({ particleCount: 80, spread: 90, origin: { y: 0.6 } });
    }, 4500);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-lg bg-slate-900 border-2 border-slate-800 rounded-3xl p-6 flex flex-col items-center relative shadow-2xl overflow-hidden">
        {/* Header */}
        <div className="w-full flex items-center justify-between mb-4">
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-yellow-500/10 text-yellow-400 rounded-xl">
              <Sparkles className="w-5 h-5" />
            </div>
            <h2 className="text-xl font-black text-slate-100 font-russo">{t.wheel}</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Wheel Container */}
        <div className="relative w-72 h-72 sm:w-80 sm:h-80 my-4 flex items-center justify-center">
          {/* Top Indicator Arrow */}
          <div className="absolute top-0 z-20 w-0 h-0 border-l-[14px] border-l-transparent border-r-[14px] border-r-transparent border-t-[28px] border-t-yellow-400 filter drop-shadow-lg" />

          {/* Rotating Wheel Disc */}
          <div
            ref={wheelRef}
            className="w-full h-full rounded-full border-4 border-yellow-500 relative overflow-hidden shadow-2xl transition-transform duration-[4500ms] ease-[cubic-bezier(0.15,0.95,0.35,1)]"
            style={{
              transform: `rotate(${rotation}deg)`
            }}
          >
            {WHEEL_PRIZES.map((prize, idx) => {
              const rotate = idx * (360 / WHEEL_PRIZES.length);
              return (
                <div
                  key={idx}
                  className="absolute top-0 left-1/2 w-1/2 h-full origin-left flex items-start justify-center pt-4 text-center font-bold text-xs"
                  style={{
                    transform: `rotate(${rotate}deg)`,
                    backgroundColor: prize.color,
                    clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0 100%)',
                    color: '#ffffff'
                  }}
                >
                  <div
                    className="transform -rotate-90 origin-center text-[11px] sm:text-xs font-black drop-shadow-md select-none mt-12"
                  >
                    <div>{prize.icon}</div>
                    <div>{prize.amount}</div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Center Hub Button */}
          <div className="absolute z-10 w-16 h-16 rounded-full bg-slate-950 border-4 border-yellow-400 flex items-center justify-center text-xl shadow-xl">
            👑
          </div>
        </div>

        {/* Won Prize Banner */}
        {wonPrize && (
          <div className="p-3 bg-yellow-500/10 border border-yellow-500/40 rounded-2xl text-center mb-4 animate-bounce">
            <span className="text-yellow-400 font-extrabold text-sm">
              🎉 Yutuq: +{wonPrize.amount} {wonPrize.type === 'coins' ? 'Tangalar 🪙' : 'Olmoslar 💎'}!
            </span>
          </div>
        )}

        {/* Spin Actions */}
        <div className="w-full flex flex-col items-center gap-2 mt-2">
          <button
            onClick={handleSpin}
            disabled={isSpinning || (!canFreeSpin && !canPaidSpin)}
            className={`w-full py-4 rounded-2xl font-black text-base shadow-xl transition flex items-center justify-center gap-2 ${
              isSpinning || (!canFreeSpin && !canPaidSpin)
                ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                : 'bg-gradient-to-r from-amber-500 via-yellow-500 to-amber-600 hover:from-amber-400 hover:to-yellow-500 text-slate-950 hover:scale-102 active:scale-98 glow-gold'
            }`}
          >
            <span>
              {isSpinning
                ? 'Aylanmoqda...'
                : canFreeSpin
                ? '🎁 BEPUL AYLANTIRISH!'
                : `🪙 150 Tangaga Aylantirish`}
            </span>
          </button>

          <p className="text-xs text-slate-400 text-center mt-1">
            Mavjud: <span className="text-amber-400 font-bold">{profile.coins} 🪙</span> | Bepul urinish: <span className="text-cyan-400 font-bold">{profile.spinsAvailable}</span>
          </p>
        </div>
      </div>
    </div>
  );
};
