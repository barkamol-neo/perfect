import React, { useState, useEffect } from 'react';
import { PlayerProfile, DailyQuest, Language } from '../../types/game';
import { sound } from '../../services/sound';
import { storage } from '../../services/storage';
import { getTranslation } from '../../services/localization';
import { X, Target, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

interface QuestsModalProps {
  profile: PlayerProfile;
  language: Language;
  isOpen: boolean;
  onClose: () => void;
  onUpdateProfile: (profile: PlayerProfile) => void;
}

export const QuestsModal: React.FC<QuestsModalProps> = ({
  language,
  isOpen,
  onClose,
  onUpdateProfile
}) => {
  const t = getTranslation(language);
  const [quests, setQuests] = useState<DailyQuest[]>([]);

  useEffect(() => {
    if (isOpen) {
      setQuests(storage.getDailyQuests());
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleClaim = (questId: string, rewardAmount: number, rewardType: 'coins' | 'diamonds') => {
    sound.playPowerup();
    confetti({ particleCount: 50, spread: 70 });

    const updated = storage.addCoinsAndDiamonds(
      rewardType === 'coins' ? rewardAmount : 0,
      rewardType === 'diamonds' ? rewardAmount : 0
    );

    const list = quests.map(q => {
      if (q.id === questId) {
        return { ...q, isClaimed: true };
      }
      return q;
    });

    storage.saveDailyQuests(list);
    setQuests(list);
    onUpdateProfile(updated);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/80 backdrop-blur-md">
      <div className="w-full max-w-2xl max-h-[85vh] bg-slate-900 border-2 border-slate-800 rounded-3xl flex flex-col overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="p-4 sm:p-6 bg-slate-950/60 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-cyan-500/10 text-cyan-400 rounded-2xl">
              <Target className="w-6 h-6" />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-black text-slate-100 font-russo">{t.quests}</h2>
              <p className="text-xs text-slate-400">{t.dailyQuestsTitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white bg-slate-800 rounded-xl transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content List */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 flex flex-col gap-3">
          {quests.map((q) => {
            const isDone = q.progress >= q.targetAmount || q.isCompleted;

            return (
              <div
                key={q.id}
                className={`p-4 rounded-2xl border flex items-center justify-between gap-4 transition ${
                  q.isClaimed
                    ? 'bg-slate-950/90 border-slate-800 opacity-80'
                    : isDone
                    ? 'bg-cyan-950/30 border-cyan-500/50 glow-cyan'
                    : 'bg-slate-950/50 border-slate-800'
                }`}
              >
                <div>
                  <h3 className="font-bold text-sm sm:text-base text-slate-100 mb-0.5">{q.title}</h3>
                  <p className="text-xs text-slate-400 mb-2">{q.description}</p>

                  <div className="flex items-center gap-2">
                    <div className="w-28 sm:w-44 h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-gradient-to-r from-cyan-500 to-blue-500"
                        style={{ width: `${Math.min(100, (q.progress / q.targetAmount) * 100)}%` }}
                      />
                    </div>
                    <span className="text-[11px] text-slate-400 font-mono">
                      {Math.min(q.targetAmount, q.progress)} / {q.targetAmount}
                    </span>
                  </div>
                </div>

                <div>
                  {q.isClaimed ? (
                    <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 rounded-xl font-bold text-xs">
                      <Check className="w-4 h-4" />
                      <span>{t.claimed}</span>
                    </div>
                  ) : isDone ? (
                    <button
                      onClick={() => handleClaim(q.id, q.rewardAmount, q.rewardType)}
                      className="px-4 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-bold text-xs rounded-xl shadow-lg transition active:scale-95"
                    >
                      {t.claim}: +{q.rewardAmount} {q.rewardType === 'coins' ? '🪙' : '💎'}
                    </button>
                  ) : (
                    <div className="text-xs font-bold text-slate-500 bg-slate-900 px-3 py-1.5 rounded-xl border border-slate-800">
                      +{q.rewardAmount} {q.rewardType === 'coins' ? '🪙' : '💎'}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
